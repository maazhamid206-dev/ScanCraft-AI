package com.scancraftai.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
