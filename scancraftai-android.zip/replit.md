# ScanCraft AI

An AI-powered mobile document scanner with edge crop, image enhancement, and multilingual OCR (English, Urdu, Arabic). Built with React + Vite + TypeScript, backed by an Express server that calls the Gemini API.

## AdMob Integration

Real Google AdMob ads are integrated via **Capacitor** (`@capacitor-community/admob`). Ads only activate when the app runs as a native Android APK — the web preview shows mock fallback UI.

| Ad type | Behaviour on Android | Behaviour in web preview |
|---|---|---|
| Banner | Native overlay rendered by SDK; React spacer reserves height | Mock banner card with close button |
| Interstitial | Full-screen native ad; auto-reloads after dismiss | Mock modal with 5-second countdown |
| Rewarded | Full-screen video; `RewardAdPluginEvents.Rewarded` grants +5 credits | Mock modal with 5-second countdown |

Ad Unit IDs live in `src/lib/admob-config.ts`. The AdMob App ID is also set in `capacitor.config.ts` (injected into `AndroidManifest.xml` by the plugin).

### Building the Android APK

The `android/` project folder is already generated and ready. Open it in Android Studio:

```bash
# Rebuild web assets + sync changes to android/ (run after any code change)
npm run cap:build

# Open android/ in Android Studio
npm run cap:open
```

**In Android Studio:**
1. Let Gradle sync finish automatically
2. Connect a device or start an emulator
3. Click **Run ▶** to install and launch, or **Build → Generate Signed Bundle/APK** for a release build

**App ID:** `com.scancraftai.app`  
**Min SDK:** 23 (Android 6.0)  
**Target SDK:** 35 (Android 15)

## Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Vite, Framer Motion
- **Backend**: Express (serves Vite in dev, static build in prod)
- **AI**: Google Gemini (`@google/genai`) for OCR and document quality analysis
- **Auth & Storage**: Firebase (Auth, Firestore, Cloud Storage)
- **PDF**: jsPDF

## Running the app

```bash
npm run dev
```

The server starts on port 5000. In development, Express proxies to Vite's dev server.

## Required secrets

| Secret | Description |
|--------|-------------|
| `GEMINI_API_KEY` | Gemini API key — get one at https://aistudio.google.com/apikey |

Firebase config is bundled in `firebase-applet-config.json` (public client config — no secret needed).

## Key files

- `server.ts` — Express server + Gemini API endpoints (`/api/ocr`, `/api/enhance-ai`)
- `src/lib/firebase.ts` — Firebase initialization
- `firebase-applet-config.json` — Firebase project config (public)
- `src/components/` — All UI screens (Scanner, Crop, Enhancer, OCR, PDF Creator, History, Settings)

## User preferences

(None recorded yet)
