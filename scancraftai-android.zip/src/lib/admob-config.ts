/**
 * AdMob configuration — production Ad Unit IDs.
 * These IDs are safe to embed in the app bundle (they are public identifiers).
 */
export const ADMOB_CONFIG = {
  /** AdMob App ID — also set in capacitor.config.ts for manifest injection */
  APP_ID: 'ca-app-pub-1729431496616324~8981139497',

  /** Banner Ad Unit ID */
  BANNER_AD_ID: 'ca-app-pub-1729431496616324/9834523338',

  /** Interstitial Ad Unit ID */
  INTERSTITIAL_AD_ID: 'ca-app-pub-1729431496616324/2789622897',

  /** Rewarded Video Ad Unit ID */
  REWARDED_AD_ID: 'ca-app-pub-1729431496616324/4662087701',
} as const;
