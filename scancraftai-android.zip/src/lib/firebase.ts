import { initializeApp, getApps, getApp } from "firebase/app";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInAnonymously,
  signOut,
  onAuthStateChanged,
  User,
} from "firebase/auth";
import {
  getFirestore,
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  where,
  deleteDoc,
} from "firebase/firestore";
import {
  getStorage,
  ref,
  uploadString,
  uploadBytes,
  getDownloadURL,
  deleteObject,
} from "firebase/storage";
import firebaseConfig from "../../firebase-applet-config.json";

// Initialize App (Singleton pattern)
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: "select_account" });

// Initialize Firestore with Database ID and Offline Persistence
let dbInstance;
const dbId = firebaseConfig.firestoreDatabaseId || "(default)";
try {
  dbInstance = initializeFirestore(app, {
    localCache: persistentLocalCache({
      tabManager: persistentMultipleTabManager(),
    }),
  }, dbId);
} catch (err) {
  dbInstance = getFirestore(app, dbId);
}

export const db = dbInstance;
export const storage = getStorage(app);

/**
 * Utility to upload Base64 or DataURL to Firebase Storage.
 * Gracefully falls back to raw dataUrl if storage fails or hits iframe limits.
 */
export async function uploadImageToStorage(
  storagePath: string,
  dataUrl: string
): Promise<string> {
  if (!dataUrl || !dataUrl.startsWith("data:")) {
    return dataUrl;
  }
  try {
    const imageRef = ref(storage, storagePath);
    await uploadString(imageRef, dataUrl, "data_url");
    const downloadUrl = await getDownloadURL(imageRef);
    return downloadUrl;
  } catch (error) {
    console.warn(`[Firebase Storage] Upload notice for ${storagePath}:`, error);
    // Return original base64 as safe fallback
    return dataUrl;
  }
}

/**
 * Utility to upload Blob (PDF file) to Firebase Storage.
 */
export async function uploadBlobToStorage(
  storagePath: string,
  blob: Blob
): Promise<string> {
  try {
    const fileRef = ref(storage, storagePath);
    await uploadBytes(fileRef, blob, { contentType: blob.type || "application/pdf" });
    const downloadUrl = await getDownloadURL(fileRef);
    return downloadUrl;
  } catch (error) {
    console.warn(`[Firebase Storage] Blob upload notice for ${storagePath}:`, error);
    return "";
  }
}

export {
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInAnonymously,
  signOut,
  onAuthStateChanged,
  doc,
  setDoc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  where,
  deleteDoc,
  collection,
};
