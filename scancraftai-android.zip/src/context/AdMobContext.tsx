import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from "react";
import { Capacitor } from "@capacitor/core";
import {
  AdMob,
  BannerAdOptions,
  BannerAdSize,
  BannerAdPosition,
  AdOptions,
  InterstitialAdPluginEvents,
  RewardAdPluginEvents,
  AdMobRewardItem,
} from "@capacitor-community/admob";
import { AdMobState } from "../types";
import { ADMOB_CONFIG } from "../lib/admob-config";

// ─── Types ────────────────────────────────────────────────────────────────────

interface AdMobContextType {
  adState: AdMobState;
  /** True when running inside a Capacitor native Android/iOS app */
  isNative: boolean;
  showInterstitial: (onClosed?: () => void) => void;
  showRewarded: (onRewardGranted?: () => void) => void;
  /** Web-only: dismiss the mock ad modal */
  dismissAdModal: () => void;
  /** Web-only: which mock modal is showing */
  activeAdModal: "interstitial" | "rewarded" | null;
  rewardPoints: number;
  useRewardPoint: () => boolean;
}

const AdMobContext = createContext<AdMobContextType | undefined>(undefined);

// ─── Provider ─────────────────────────────────────────────────────────────────

export const AdMobProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const isNative = Capacitor.isNativePlatform();

  const [adState, setAdState] = useState<AdMobState>({
    bannerEnabled: true,
    interstitialLoaded: false,
    rewardedLoaded: false,
    rewardPoints: 3,
  });

  // Web-only mock modal state
  const [activeAdModal, setActiveAdModal] = useState<"interstitial" | "rewarded" | null>(null);
  const [onAdClosedCallback, setOnAdClosedCallback] = useState<(() => void) | null>(null);
  const [onRewardCallback, setOnRewardCallback] = useState<(() => void) | null>(null);

  // Listeners cleanup refs
  const listenersRef = useRef<Array<{ remove: () => Promise<void> }>>([]);

  // ── Native AdMob initialisation ─────────────────────────────────────────────

  useEffect(() => {
    if (!isNative) return;

    let mounted = true;

    const initAdMob = async () => {
      try {
        await AdMob.initialize({
          initializeForTesting: false,
          testingDevices: [],
        });
        // Request iOS 14+ App Tracking Transparency permission
        await AdMob.requestTrackingAuthorization().catch(() => {});

        if (!mounted) return;

        // Show banner immediately after init
        await showBannerNative();

        // Pre-load full-screen ads
        await preloadInterstitial();
        await preloadRewarded();
      } catch (err) {
        console.warn("[AdMob] Initialization error:", err);
      }
    };

    initAdMob();

    return () => {
      mounted = false;
      // Remove all listeners on unmount
      listenersRef.current.forEach((l) => l.remove().catch(() => {}));
      listenersRef.current = [];
      // Hide banner on unmount
      if (isNative) AdMob.hideBanner().catch(() => {});
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isNative]);

  // ── Native banner ────────────────────────────────────────────────────────────

  const showBannerNative = async () => {
    try {
      const options: BannerAdOptions = {
        adId: ADMOB_CONFIG.BANNER_AD_ID,
        adSize: BannerAdSize.ADAPTIVE_BANNER,
        position: BannerAdPosition.BOTTOM_CENTER,
        margin: 0,
        isTesting: false,
      };
      await AdMob.showBanner(options);
    } catch (err) {
      console.warn("[AdMob] Banner error:", err);
    }
  };

  // ── Native interstitial ──────────────────────────────────────────────────────

  const preloadInterstitial = useCallback(async () => {
    try {
      const options: AdOptions = { adId: ADMOB_CONFIG.INTERSTITIAL_AD_ID };
      await AdMob.prepareInterstitial(options);
      setAdState((prev) => ({ ...prev, interstitialLoaded: true }));
    } catch (err) {
      console.warn("[AdMob] Interstitial preload error:", err);
      setAdState((prev) => ({ ...prev, interstitialLoaded: false }));
    }
  }, []);

  const preloadRewarded = useCallback(async () => {
    try {
      const options: AdOptions = { adId: ADMOB_CONFIG.REWARDED_AD_ID };
      await AdMob.prepareRewardVideoAd(options);
      setAdState((prev) => ({ ...prev, rewardedLoaded: true }));
    } catch (err) {
      console.warn("[AdMob] Rewarded preload error:", err);
      setAdState((prev) => ({ ...prev, rewardedLoaded: false }));
    }
  }, []);

  // ── showInterstitial ─────────────────────────────────────────────────────────

  const showInterstitial = useCallback(
    (onClosed?: () => void) => {
      if (!isNative) {
        // Web fallback: show mock modal
        setOnAdClosedCallback(() => onClosed || null);
        setActiveAdModal("interstitial");
        return;
      }

      // Native path
      const show = async () => {
        try {
          // Listen for dismissal once
          const dismissedListener = await AdMob.addListener(
            InterstitialAdPluginEvents.Dismissed,
            () => {
              setAdState((prev) => ({ ...prev, interstitialLoaded: false }));
              dismissedListener.remove();
              onClosed?.();
              // Re-preload for next use
              preloadInterstitial();
            }
          );
          listenersRef.current.push(dismissedListener);

          await AdMob.showInterstitial();
        } catch (err) {
          console.warn("[AdMob] showInterstitial error:", err);
          onClosed?.();
          // Try to reload in case it wasn't ready
          preloadInterstitial();
        }
      };

      show();
    },
    [isNative, preloadInterstitial]
  );

  // ── showRewarded ─────────────────────────────────────────────────────────────

  const showRewarded = useCallback(
    (onRewardGranted?: () => void) => {
      if (!isNative) {
        // Web fallback: show mock modal
        setOnRewardCallback(() => onRewardGranted || null);
        setActiveAdModal("rewarded");
        return;
      }

      // Native path
      const show = async () => {
        try {
          // Listen for the reward event once
          const rewardListener = await AdMob.addListener(
            RewardAdPluginEvents.Rewarded,
            (reward: AdMobRewardItem) => {
              console.log("[AdMob] Reward earned:", reward);
              setAdState((prev) => ({ ...prev, rewardPoints: prev.rewardPoints + 5 }));
              rewardListener.remove();
              onRewardGranted?.();
            }
          );
          listenersRef.current.push(rewardListener);

          // Listen for dismissal (video ended or skipped after threshold)
          const dismissedListener = await AdMob.addListener(
            RewardAdPluginEvents.Dismissed,
            () => {
              setAdState((prev) => ({ ...prev, rewardedLoaded: false }));
              dismissedListener.remove();
              // Re-preload for next use
              preloadRewarded();
            }
          );
          listenersRef.current.push(dismissedListener);

          await AdMob.showRewardVideoAd();
        } catch (err) {
          console.warn("[AdMob] showRewarded error:", err);
          preloadRewarded();
        }
      };

      show();
    },
    [isNative, preloadRewarded]
  );

  // ── Web mock modal dismiss ────────────────────────────────────────────────────

  const dismissAdModal = useCallback(() => {
    if (activeAdModal === "rewarded" && onRewardCallback) {
      setAdState((prev) => ({ ...prev, rewardPoints: prev.rewardPoints + 5 }));
      onRewardCallback();
    }
    if (onAdClosedCallback) {
      onAdClosedCallback();
    }
    setActiveAdModal(null);
    setOnAdClosedCallback(null);
    setOnRewardCallback(null);
  }, [activeAdModal, onRewardCallback, onAdClosedCallback]);

  // ── Reward credit consumption ─────────────────────────────────────────────────

  const useRewardPoint = useCallback((): boolean => {
    if (adState.rewardPoints > 0) {
      setAdState((prev) => ({ ...prev, rewardPoints: prev.rewardPoints - 1 }));
      return true;
    }
    return false;
  }, [adState.rewardPoints]);

  return (
    <AdMobContext.Provider
      value={{
        adState,
        isNative,
        showInterstitial,
        showRewarded,
        dismissAdModal,
        activeAdModal,
        rewardPoints: adState.rewardPoints,
        useRewardPoint,
      }}
    >
      {children}
    </AdMobContext.Provider>
  );
};

export const useAdMob = () => {
  const context = useContext(AdMobContext);
  if (!context) throw new Error("useAdMob must be used within an AdMobProvider");
  return context;
};
