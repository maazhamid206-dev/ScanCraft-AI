import React, { createContext, useContext, useEffect, useState } from "react";
import {
  ActiveTab,
  AppSettings,
  CornerPoints,
  FilterSettings,
  SavedDocument,
  ScanPage,
} from "../types";
import {
  autoDetectCornersFromImage,
  cropAndWarpPerspective,
  DEFAULT_CORNERS,
  DEFAULT_FILTERS,
  generateSampleDocumentImage,
  processImageFilters,
} from "../utils/imageProcessing";
import { useAuth } from "./AuthContext";
import {
  db,
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  uploadImageToStorage,
} from "../lib/firebase";

interface DocumentContextType {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  draftPages: ScanPage[];
  activePageIndex: number;
  setActivePageIndex: (idx: number) => void;
  savedDocuments: SavedDocument[];
  settings: AppSettings;
  updateSettings: (newSettings: Partial<AppSettings>) => void;

  startNewScan: () => void;
  addPageToDraft: (imageSrc: string) => Promise<void>;
  importFromGallery: (files: FileList | File[]) => Promise<void>;
  updatePageCorners: (pageId: string, corners: CornerPoints) => Promise<void>;
  updatePageFilter: (pageId: string, filters: FilterSettings) => Promise<void>;
  setPageRotation: (pageId: string, rotationDegrees: number) => Promise<void>;
  reorderDraftPages: (fromIdx: number, toIdx: number) => void;
  deleteDraftPage: (pageId: string) => void;
  saveDraftToHistory: (title: string, category?: any) => Promise<SavedDocument>;
  deleteSavedDocument: (docId: string) => void;
  loadSavedDocToDraft: (doc: SavedDocument) => void;
  loadSampleDocument: (type?: "invoice" | "urdu_doc" | "arabic_doc") => Promise<void>;
}

const DEFAULT_SETTINGS: AppSettings = {
  theme: "system",
  imageQuality: "high",
  pdfQuality: "high",
  defaultLanguage: "Auto",
  autoCropEnabled: true,
  aiEnhanceByDefault: true,
  adMobTestMode: true,
  soundEffects: true,
};

const DocumentContext = createContext<DocumentContextType | undefined>(undefined);

export const DocumentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();

  const [activeTab, setActiveTab] = useState<ActiveTab>("home");
  const [draftPages, setDraftPages] = useState<ScanPage[]>([]);
  const [activePageIndex, setActivePageIndex] = useState<number>(0);

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem("scancraft_settings");
    return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
  });

  const [savedDocuments, setSavedDocuments] = useState<SavedDocument[]>(() => {
    const saved = localStorage.getItem("scancraft_history");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return [];
      }
    }
    return [];
  });

  // Firestore Realtime Subscription for authenticated user
  useEffect(() => {
    if (!user) return;

    const q = query(collection(db, "Documents"), where("ownerId", "==", user.uid));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const firestoreDocs: SavedDocument[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as SavedDocument;
          firestoreDocs.push({
            ...data,
            id: docSnap.id,
            documentId: docSnap.id,
          });
        });
        if (firestoreDocs.length > 0) {
          // Sort by latest createdAt
          firestoreDocs.sort(
            (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
          );
          setSavedDocuments(firestoreDocs);
        }
      },
      (err) => {
        console.warn("[Firestore Documents snapshot error]:", err);
      }
    );

    return () => unsubscribe();
  }, [user]);

  // Save to localStorage on state changes
  useEffect(() => {
    localStorage.setItem("scancraft_settings", JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem("scancraft_history", JSON.stringify(savedDocuments));
  }, [savedDocuments]);

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const startNewScan = () => {
    setDraftPages([]);
    setActivePageIndex(0);
    setActiveTab("scanner");
  };

  const addPageToDraft = async (imageSrc: string) => {
    const id = `page_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    // Create temp image to auto-detect corners
    const tempImg = new Image();
    tempImg.crossOrigin = "anonymous";
    await new Promise((res) => {
      tempImg.onload = res;
      tempImg.src = imageSrc;
    });

    const corners = settings.autoCropEnabled
      ? autoDetectCornersFromImage(tempImg)
      : DEFAULT_CORNERS;

    const cropped = await cropAndWarpPerspective(imageSrc, corners, 0);
    const initialFilters = settings.aiEnhanceByDefault
      ? { ...DEFAULT_FILTERS, preset: "magic_bw" as const }
      : DEFAULT_FILTERS;

    const enhanced = await processImageFilters(cropped, initialFilters);

    const newPage: ScanPage = {
      id,
      originalImage: imageSrc,
      croppedImage: cropped,
      enhancedImage: enhanced,
      corners,
      rotation: 0,
      filters: initialFilters,
    };

    setDraftPages((prev) => [...prev, newPage]);
    setActivePageIndex(draftPages.length);
  };

  const importFromGallery = async (files: FileList | File[]) => {
    const fileArray = Array.from(files);
    for (const file of fileArray) {
      if (file.type.startsWith("image/")) {
        const reader = new FileReader();
        await new Promise<void>((resolve) => {
          reader.onload = async (e) => {
            const dataUrl = e.target?.result as string;
            if (dataUrl) {
              await addPageToDraft(dataUrl);
            }
            resolve();
          };
          reader.readAsDataURL(file);
        });
      }
    }
    if (fileArray.length > 0) {
      setActiveTab("crop");
    }
  };

  const updatePageCorners = async (pageId: string, corners: CornerPoints) => {
    setDraftPages((prev) => {
      return prev.map((page) => {
        if (page.id === pageId) {
          return { ...page, corners };
        }
        return page;
      });
    });

    const targetPage = draftPages.find((p) => p.id === pageId);
    if (!targetPage) return;

    const cropped = await cropAndWarpPerspective(
      targetPage.originalImage,
      corners,
      targetPage.rotation
    );
    const enhanced = await processImageFilters(cropped, targetPage.filters);

    setDraftPages((prev) => {
      return prev.map((page) => {
        if (page.id === pageId) {
          return { ...page, corners, croppedImage: cropped, enhancedImage: enhanced };
        }
        return page;
      });
    });
  };

  const updatePageFilter = async (pageId: string, filters: FilterSettings) => {
    const targetPage = draftPages.find((p) => p.id === pageId);
    if (!targetPage) return;

    const baseImage = targetPage.croppedImage || targetPage.originalImage;
    const enhanced = await processImageFilters(baseImage, filters);

    setDraftPages((prev) =>
      prev.map((p) => (p.id === pageId ? { ...p, filters, enhancedImage: enhanced } : p))
    );
  };

  const setPageRotation = async (pageId: string, rotationDegrees: number) => {
    const targetPage = draftPages.find((p) => p.id === pageId);
    if (!targetPage) return;

    const cropped = await cropAndWarpPerspective(
      targetPage.originalImage,
      targetPage.corners,
      rotationDegrees
    );
    const enhanced = await processImageFilters(cropped, targetPage.filters);

    setDraftPages((prev) =>
      prev.map((p) =>
        p.id === pageId
          ? {
              ...p,
              rotation: rotationDegrees,
              croppedImage: cropped,
              enhancedImage: enhanced,
            }
          : p
      )
    );
  };

  const reorderDraftPages = (fromIdx: number, toIdx: number) => {
    setDraftPages((prev) => {
      const result = Array.from(prev);
      const [removed] = result.splice(fromIdx, 1);
      result.splice(toIdx, 0, removed);
      return result;
    });
    setActivePageIndex(toIdx);
  };

  const deleteDraftPage = (pageId: string) => {
    setDraftPages((prev) => {
      const filtered = prev.filter((p) => p.id !== pageId);
      if (activePageIndex >= filtered.length && filtered.length > 0) {
        setActivePageIndex(filtered.length - 1);
      }
      return filtered;
    });
  };

  const saveDraftToHistory = async (title: string, category: any = "Other"): Promise<SavedDocument> => {
    const docId = `doc_${Date.now()}`;
    const now = new Date().toISOString();
    const ownerId = user?.uid || "guest";

    const firstPage = draftPages[0];
    let origStorageUrl = firstPage?.originalImage || "";
    let enhStorageUrl = firstPage?.enhancedImage || "";

    // Upload first page images to Firebase Storage if user authenticated
    if (user && firstPage) {
      origStorageUrl = await uploadImageToStorage(
        `scans/${user.uid}/${docId}_orig.jpg`,
        firstPage.originalImage
      );
      enhStorageUrl = await uploadImageToStorage(
        `scans/${user.uid}/${docId}_enh.jpg`,
        firstPage.enhancedImage || firstPage.croppedImage
      );
    }

    const extractedText = draftPages
      .map((p) => p.ocrResult?.text)
      .filter(Boolean)
      .join("\n\n");

    const newDoc: SavedDocument = {
      id: docId,
      documentId: docId,
      ownerId: ownerId,
      title: title || `Scan_${new Date().toLocaleDateString("en-US").replace(/\//g, "-")}`,
      fileName: title || `Scan_${new Date().toLocaleDateString("en-US").replace(/\//g, "-")}`,
      originalImage: origStorageUrl,
      enhancedImage: enhStorageUrl,
      pdfFile: "",
      extractedText: extractedText || "",
      language: firstPage?.ocrResult?.detectedLanguage || settings.defaultLanguage || "Auto",
      createdAt: now,
      updatedAt: now,
      pages: draftPages,
      category,
      tags: ["scancraft", "scanned"],
      pdfQuality: settings.pdfQuality,
    };

    // Save to Firestore if user logged in
    if (user) {
      try {
        await setDoc(doc(db, "Documents", docId), newDoc);
      } catch (err) {
        console.warn("[Firestore save error]:", err);
      }
    }

    setSavedDocuments((prev) => [newDoc, ...prev]);
    return newDoc;
  };

  const deleteSavedDocument = async (docId: string) => {
    if (user) {
      try {
        await deleteDoc(doc(db, "Documents", docId));
      } catch (err) {
        console.warn("[Firestore delete error]:", err);
      }
    }
    setSavedDocuments((prev) => prev.filter((doc) => doc.id !== docId));
  };

  const loadSavedDocToDraft = (doc: SavedDocument) => {
    setDraftPages(doc.pages);
    setActivePageIndex(0);
    setActiveTab("enhancer");
  };

  const loadSampleDocument = async (type: "invoice" | "urdu_doc" | "arabic_doc" = "invoice") => {
    const sampleImg = generateSampleDocumentImage(type);
    setDraftPages([]);
    await addPageToDraft(sampleImg);
    setActiveTab("crop");
  };

  return (
    <DocumentContext.Provider
      value={{
        activeTab,
        setActiveTab,
        draftPages,
        activePageIndex,
        setActivePageIndex,
        savedDocuments,
        settings,
        updateSettings,
        startNewScan,
        addPageToDraft,
        importFromGallery,
        updatePageCorners,
        updatePageFilter,
        setPageRotation,
        reorderDraftPages,
        deleteDraftPage,
        saveDraftToHistory,
        deleteSavedDocument,
        loadSavedDocToDraft,
        loadSampleDocument,
      }}
    >
      {children}
    </DocumentContext.Provider>
  );
};

export const useDocument = () => {
  const context = useContext(DocumentContext);
  if (!context) {
    throw new Error("useDocument must be used within a DocumentProvider");
  }
  return context;
};
