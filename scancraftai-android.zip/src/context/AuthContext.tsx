import React, { createContext, useContext, useEffect, useState } from "react";
import { User } from "firebase/auth";
import {
  auth,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInAnonymously,
  signOut,
  onAuthStateChanged,
  db,
  doc,
  setDoc,
  getDoc,
  onSnapshot,
} from "../lib/firebase";
import { UserProfile } from "../types";

interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  isGuest: boolean;
  showAuthModal: boolean;
  setShowAuthModal: (show: boolean) => void;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (email: string, pass: string, fullName: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  loginAsGuest: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);

  useEffect(() => {
    let unsubscribeDoc: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Fetch or create user profile in Firestore Users collection
        const userDocRef = doc(db, "Users", currentUser.uid);
        try {
          const snapshot = await getDoc(userDocRef);
          if (!snapshot.exists()) {
            const newProfile: UserProfile = {
              uid: currentUser.uid,
              fullName: currentUser.displayName || (currentUser.isAnonymous ? "Guest User" : "ScanCraft User"),
              email: currentUser.email || (currentUser.isAnonymous ? "guest@scancraft.app" : ""),
              profilePhoto: currentUser.photoURL || "",
              isGuest: currentUser.isAnonymous,
              createdAt: new Date().toISOString(),
            };
            await setDoc(userDocRef, newProfile);
            setUserProfile(newProfile);
          } else {
            setUserProfile(snapshot.data() as UserProfile);
          }
        } catch (err) {
          console.warn("[AuthContext] Profile fetch warning:", err);
          // Fallback in-memory profile
          setUserProfile({
            uid: currentUser.uid,
            fullName: currentUser.displayName || (currentUser.isAnonymous ? "Guest User" : "ScanCraft User"),
            email: currentUser.email || "",
            profilePhoto: currentUser.photoURL || "",
            isGuest: currentUser.isAnonymous,
            createdAt: new Date().toISOString(),
          });
        }

        // Realtime listener for User Profile updates
        unsubscribeDoc = onSnapshot(
          userDocRef,
          (docSnap) => {
            if (docSnap.exists()) {
              setUserProfile(docSnap.data() as UserProfile);
            }
          },
          (err) => console.warn("[AuthContext] Firestore User snapshot error:", err)
        );
      } else {
        if (unsubscribeDoc) unsubscribeDoc();
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeDoc) unsubscribeDoc();
    };
  }, []);

  const loginWithEmail = async (email: string, pass: string) => {
    await signInWithEmailAndPassword(auth, email, pass);
    setShowAuthModal(false);
  };

  const signUpWithEmail = async (email: string, pass: string, fullName: string) => {
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    const newProfile: UserProfile = {
      uid: cred.user.uid,
      fullName: fullName || "ScanCraft User",
      email: cred.user.email || email,
      profilePhoto: "",
      isGuest: false,
      createdAt: new Date().toISOString(),
    };
    await setDoc(doc(db, "Users", cred.user.uid), newProfile);
    setUserProfile(newProfile);
    setShowAuthModal(false);
  };

  const loginWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const userDocRef = doc(db, "Users", result.user.uid);
      const snapshot = await getDoc(userDocRef);
      if (!snapshot.exists()) {
        const newProfile: UserProfile = {
          uid: result.user.uid,
          fullName: result.user.displayName || "ScanCraft User",
          email: result.user.email || "",
          profilePhoto: result.user.photoURL || "",
          isGuest: false,
          createdAt: new Date().toISOString(),
        };
        await setDoc(userDocRef, newProfile);
        setUserProfile(newProfile);
      }
      setShowAuthModal(false);
    } catch (err: any) {
      console.error("[Google Auth Error]:", err);
      throw err;
    }
  };

  const loginAsGuest = async () => {
    await signInAnonymously(auth);
    setShowAuthModal(false);
  };

  const logout = async () => {
    await signOut(auth);
    setUserProfile(null);
  };

  const isGuest = Boolean(user?.isAnonymous || userProfile?.isGuest);

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        loading,
        isGuest,
        showAuthModal,
        setShowAuthModal,
        loginWithEmail,
        signUpWithEmail,
        loginWithGoogle,
        loginAsGuest,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
