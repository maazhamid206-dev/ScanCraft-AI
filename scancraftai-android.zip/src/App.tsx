import React, { useState } from "react";
import { ThemeProvider } from "./context/ThemeContext";
import { AdMobProvider } from "./context/AdMobContext";
import { AuthProvider } from "./context/AuthContext";
import { DocumentProvider, useDocument } from "./context/DocumentContext";
import { Splash } from "./components/Splash";
import { HeaderNav } from "./components/HeaderNav";
import { BottomNav } from "./components/BottomNav";
import { HomeScreen } from "./components/HomeScreen";
import { CameraScanner } from "./components/CameraScanner";
import { CropPerspective } from "./components/CropPerspective";
import { EnhancerView } from "./components/EnhancerView";
import { OcrView } from "./components/OcrView";
import { PdfCreatorView } from "./components/PdfCreatorView";
import { HistoryView } from "./components/HistoryView";
import { SettingsView } from "./components/SettingsView";
import { AdMobAdModals } from "./components/AdMobComponents";
import { AuthModal } from "./components/AuthModal";

function MainAppContent() {
  const { activeTab } = useDocument();

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors font-sans antialiased">
      <HeaderNav />

      <main className="max-w-md mx-auto px-4 pt-4">
        {activeTab === "home" && <HomeScreen />}
        {activeTab === "scanner" && <CameraScanner />}
        {activeTab === "crop" && <CropPerspective />}
        {activeTab === "enhancer" && <EnhancerView />}
        {activeTab === "ocr" && <OcrView />}
        {activeTab === "pdf_creator" && <PdfCreatorView />}
        {activeTab === "history" && <HistoryView />}
        {activeTab === "settings" && <SettingsView />}
      </main>

      <BottomNav />
      <AdMobAdModals />
      <AuthModal />
    </div>
  );
}

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(true);

  return (
    <ThemeProvider>
      <AuthProvider>
        <AdMobProvider>
          <DocumentProvider>
            {showSplash ? (
              <Splash onFinish={() => setShowSplash(false)} />
            ) : (
              <MainAppContent />
            )}
          </DocumentProvider>
        </AdMobProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
