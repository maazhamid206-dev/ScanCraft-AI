import React, { useEffect, useRef, useState } from "react";
import { Camera, RefreshCw, Zap, Grid, Image as ImageIcon, Check, Sparkles, AlertCircle } from "lucide-react";
import { useDocument } from "../context/DocumentContext";
import { generateSampleDocumentImage } from "../utils/imageProcessing";

export const CameraScanner: React.FC = () => {
  const { addPageToDraft, draftPages, setActiveTab, importFromGallery } = useDocument();

  const videoRef = useRef<HTMLVideoElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const [streamActive, setStreamActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [flashOn, setFlashOn] = useState<boolean>(false);
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [capturing, setCapturing] = useState<boolean>(false);

  useEffect(() => {
    let activeStream: MediaStream | null = null;

    async function initCamera() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: "environment" },
            width: { ideal: 1920 },
            height: { ideal: 1080 },
          },
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
          activeStream = stream;
          setStreamActive(true);
        }
      } catch (err: any) {
        console.warn("Camera access unavailable, fallback to sample capture:", err);
        setCameraError(
          "Camera access is blocked or unavailable in preview. You can capture instant sample scans or import from gallery below."
        );
      }
    }

    initCamera();

    return () => {
      if (activeStream) {
        activeStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const handleCapture = async () => {
    setCapturing(true);

    let captureDataUrl = "";

    if (streamActive && videoRef.current) {
      const video = videoRef.current;
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        captureDataUrl = canvas.toDataURL("image/jpeg", 0.95);
      }
    }

    if (!captureDataUrl) {
      // Fallback generate realistic document photo
      captureDataUrl = generateSampleDocumentImage("invoice");
    }

    await addPageToDraft(captureDataUrl);
    setCapturing(false);
  };

  const handleGalleryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      importFromGallery(e.target.files);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] max-w-md mx-auto relative select-none pb-16">
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleGalleryChange}
        className="hidden"
      />

      {/* Top Camera Controls Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-900 text-white rounded-t-3xl border-b border-slate-800">
        <button
          onClick={() => setFlashOn(!flashOn)}
          className={`p-2 rounded-full transition-colors ${
            flashOn ? "bg-amber-500 text-slate-950 font-bold" : "bg-slate-800 text-slate-300"
          }`}
          title="Toggle Flash"
        >
          <Zap className="w-4 h-4" />
        </button>

        <div className="flex items-center space-x-1 px-3 py-1 bg-slate-800/80 rounded-full text-xs font-semibold text-teal-400 border border-teal-500/30">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Auto Edge Detection Active</span>
        </div>

        <button
          onClick={() => setShowGrid(!showGrid)}
          className={`p-2 rounded-full transition-colors ${
            showGrid ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-300"
          }`}
          title="Toggle Grid"
        >
          <Grid className="w-4 h-4" />
        </button>
      </div>

      {/* Camera Viewfinder Container */}
      <div className="relative flex-1 bg-slate-950 flex items-center justify-center overflow-hidden">
        {streamActive ? (
          <video
            ref={videoRef}
            playsInline
            muted
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="p-6 text-center text-slate-300 flex flex-col items-center max-w-xs">
            <div className="w-16 h-16 rounded-3xl bg-indigo-950/80 text-indigo-400 border border-indigo-800/50 flex items-center justify-center mb-3">
              <Camera className="w-8 h-8 animate-pulse" />
            </div>
            <p className="text-xs font-bold text-slate-200 mb-1">
              {cameraError ? "Simulated Document Viewfinder" : "Initializing Camera..."}
            </p>
            <p className="text-[11px] text-slate-400 mb-4">
              Tap the Shutter Button below to take a scan or import from your photo gallery.
            </p>
          </div>
        )}

        {/* Animated Document Overlay Guides */}
        <div className="absolute inset-8 border-2 border-dashed border-teal-400/70 rounded-2xl pointer-events-none flex flex-col justify-between p-3">
          <div className="flex justify-between">
            <div className="w-6 h-6 border-t-4 border-l-4 border-teal-400 rounded-tl-lg" />
            <div className="w-6 h-6 border-t-4 border-r-4 border-teal-400 rounded-tr-lg" />
          </div>

          <div className="text-center">
            <span className="text-[10px] font-bold tracking-widest text-teal-300 uppercase bg-slate-900/80 px-3 py-1 rounded-full border border-teal-500/40 backdrop-blur-xs">
              Align Document Within Frame
            </span>
          </div>

          <div className="flex justify-between">
            <div className="w-6 h-6 border-b-4 border-l-4 border-teal-400 rounded-bl-lg" />
            <div className="w-6 h-6 border-b-4 border-r-4 border-teal-400 rounded-br-lg" />
          </div>
        </div>

        {/* Grid Overlay */}
        {showGrid && (
          <div className="absolute inset-0 pointer-events-none grid grid-cols-3 grid-rows-3 opacity-20 border border-slate-100">
            <div className="border-r border-b border-slate-100" />
            <div className="border-r border-b border-slate-100" />
            <div className="border-b border-slate-100" />
            <div className="border-r border-b border-slate-100" />
            <div className="border-r border-b border-slate-100" />
            <div className="border-b border-slate-100" />
            <div className="border-r border-slate-100" />
            <div className="border-r border-slate-100" />
            <div />
          </div>
        )}
      </div>

      {/* Bottom Shutter & Action Bar */}
      <div className="bg-slate-900 p-4 rounded-b-3xl border-t border-slate-800 flex items-center justify-between">
        {/* Gallery Button */}
        <button
          onClick={() => galleryInputRef.current?.click()}
          className="flex flex-col items-center space-y-1 text-slate-300 hover:text-white"
        >
          <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center">
            <ImageIcon className="w-5 h-5 text-indigo-400" />
          </div>
          <span className="text-[10px] font-semibold">Gallery</span>
        </button>

        {/* Shutter Button */}
        <button
          onClick={handleCapture}
          disabled={capturing}
          className="relative w-18 h-18 rounded-full border-4 border-white flex items-center justify-center p-1 group active:scale-95 transition-transform"
        >
          <div className="w-full h-full rounded-full bg-indigo-600 group-hover:bg-indigo-500 transition-colors flex items-center justify-center text-white shadow-lg">
            {capturing ? (
              <RefreshCw className="w-6 h-6 animate-spin" />
            ) : (
              <Camera className="w-7 h-7" />
            )}
          </div>
        </button>

        {/* Finish Batch Scan Button */}
        <button
          onClick={() => {
            if (draftPages.length > 0) {
              setActiveTab("crop");
            } else {
              handleCapture();
            }
          }}
          className="flex flex-col items-center space-y-1 text-slate-300 hover:text-white"
        >
          <div className="relative w-10 h-10 rounded-full bg-teal-500/20 border border-teal-500/40 text-teal-400 flex items-center justify-center font-bold text-xs">
            {draftPages.length > 0 ? (
              <>
                <span>{draftPages.length}</span>
                <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-teal-400" />
              </>
            ) : (
              <Check className="w-5 h-5" />
            )}
          </div>
          <span className="text-[10px] font-semibold">
            {draftPages.length > 0 ? "Proceed" : "Ready"}
          </span>
        </button>
      </div>
    </div>
  );
};
