import React from "react";
import { Scan, Sun, Moon, Laptop, Settings, Award, ArrowLeft, User, ShieldCheck } from "lucide-react";
import { useTheme } from "../context/ThemeContext";
import { useDocument } from "../context/DocumentContext";
import { useAdMob } from "../context/AdMobContext";
import { useAuth } from "../context/AuthContext";

export const HeaderNav: React.FC = () => {
  const { theme, setTheme } = useTheme();
  const { activeTab, setActiveTab } = useDocument();
  const { rewardPoints, showRewarded } = useAdMob();
  const { userProfile, isGuest, setShowAuthModal } = useAuth();

  const getTitle = () => {
    switch (activeTab) {
      case "home":
        return "ScanCraft AI";
      case "scanner":
        return "Camera Scanner";
      case "crop":
        return "Crop & Perspective";
      case "enhancer":
        return "AI Document Enhancer";
      case "ocr":
        return "Multilingual OCR";
      case "pdf_creator":
        return "PDF Creator";
      case "history":
        return "Scan History";
      case "settings":
        return "Settings";
      default:
        return "ScanCraft AI";
    }
  };

  const cycleTheme = () => {
    if (theme === "light") setTheme("dark");
    else if (theme === "dark") setTheme("system");
    else setTheme("light");
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-md mx-auto px-4 h-14 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          {activeTab !== "home" && (
            <button
              onClick={() => setActiveTab("home")}
              className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition-colors"
              aria-label="Back to home"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}

          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
              <Scan className="w-4 h-4" />
            </div>
            <div>
              <h1 className="font-bold text-base text-slate-900 dark:text-white leading-none">
                {getTitle()}
              </h1>
              {activeTab === "home" && (
                <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-medium">
                  Material 3 AI Scanner
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-1.5">
          {/* Rewarded Points Badge */}
          <button
            onClick={() => showRewarded()}
            className="flex items-center space-x-1 px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20 text-xs font-semibold hover:bg-amber-500/20 transition-colors"
            title="Earn Free AI Credits"
          >
            <Award className="w-3.5 h-3.5 text-amber-500" />
            <span>{rewardPoints} AI Credits</span>
          </button>

          {/* Theme Switcher Button */}
          <button
            onClick={cycleTheme}
            className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
            title={`Current theme: ${theme}. Click to change.`}
          >
            {theme === "light" && <Sun className="w-4 h-4 text-amber-500" />}
            {theme === "dark" && <Moon className="w-4 h-4 text-indigo-400" />}
            {theme === "system" && <Laptop className="w-4 h-4 text-teal-500" />}
          </button>

          {/* Auth / Profile Button */}
          <button
            onClick={() => setShowAuthModal(true)}
            className="p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center"
            title={userProfile ? `Account: ${userProfile.fullName}` : "Sign In / Register"}
          >
            {userProfile?.profilePhoto ? (
              <img
                src={userProfile.profilePhoto}
                alt="Profile"
                className="w-7 h-7 rounded-full object-cover ring-2 ring-indigo-500"
              />
            ) : userProfile && !isGuest ? (
              <div className="w-7 h-7 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shadow-xs">
                {userProfile.fullName.charAt(0).toUpperCase()}
              </div>
            ) : (
              <div className="p-1.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                <User className="w-4 h-4" />
              </div>
            )}
          </button>

          {/* Settings icon */}
          <button
            onClick={() => setActiveTab("settings")}
            className={`p-2 rounded-full transition-colors ${
              activeTab === "settings"
                ? "bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400"
                : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
            }`}
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
