import React, { useState } from "react";
import {
  FileText,
  Download,
  Share2,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  Check,
  RefreshCw,
  Sparkles,
  Lock,
} from "lucide-react";
import { useDocument } from "../context/DocumentContext";
import { generatePDF } from "../utils/pdfGenerator";

export const PdfCreatorView: React.FC = () => {
  const {
    draftPages,
    reorderDraftPages,
    deleteDraftPage,
    startNewScan,
    saveDraftToHistory,
    setActiveTab,
  } = useDocument();

  const [pdfTitle, setPdfTitle] = useState<string>("ScanCraft_Document_1");
  const [pageSize, setPageSize] = useState<"a4" | "letter" | "fit">("a4");
  const [orientation, setOrientation] = useState<"portrait" | "landscape">("portrait");
  const [quality, setQuality] = useState<"high" | "medium" | "low">("high");
  const [addWatermark, setAddWatermark] = useState<boolean>(false);
  const [watermarkText, setWatermarkText] = useState<string>("ScanCraft AI");

  const [generating, setGenerating] = useState<boolean>(false);

  if (draftPages.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center space-y-4 h-80">
        <div className="w-16 h-16 rounded-3xl bg-teal-100 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center">
          <FileText className="w-8 h-8" />
        </div>
        <div>
          <h3 className="font-extrabold text-slate-800 dark:text-slate-200">No Pages to Convert</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-xs">
            Scan pages or import document images first to build your custom PDF.
          </p>
        </div>
        <button
          onClick={startNewScan}
          className="px-5 py-2.5 rounded-2xl bg-indigo-600 text-white font-extrabold text-xs shadow-md"
        >
          Start New Scan
        </button>
      </div>
    );
  }

  const handleDownloadPDF = async () => {
    setGenerating(true);
    try {
      const { blob, filename } = await generatePDF(draftPages, {
        title: pdfTitle,
        quality,
        pageSize,
        orientation,
        addWatermark,
        watermarkText,
      });

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);

      await saveDraftToHistory(pdfTitle, "PDF Scan");
    } catch (err) {
      console.error("PDF generation failed:", err);
    } finally {
      setGenerating(false);
    }
  };

  const handleSharePDF = async () => {
    setGenerating(true);
    try {
      const { blob, filename } = await generatePDF(draftPages, {
        title: pdfTitle,
        quality,
        pageSize,
        orientation,
        addWatermark,
        watermarkText,
      });

      const file = new File([blob], filename, { type: "application/pdf" });
      if (navigator.share && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: pdfTitle,
          text: "Scanned document created with ScanCraft AI",
        });
      } else {
        handleDownloadPDF();
      }
    } catch (err) {
      console.error("PDF share failed:", err);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="flex flex-col space-y-4 pb-20 select-none">
      {/* PDF Document Options */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
        <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center space-x-2">
          <FileText className="w-4 h-4 text-teal-500" />
          <span>PDF Configuration</span>
        </h3>

        {/* Title Rename */}
        <div>
          <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">
            PDF File Name
          </label>
          <input
            type="text"
            value={pdfTitle}
            onChange={(e) => setPdfTitle(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>

        {/* Page Size & Orientation */}
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">
              Page Format
            </label>
            <select
              value={pageSize}
              onChange={(e: any) => setPageSize(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
            >
              <option value="a4">Standard A4</option>
              <option value="letter">US Letter</option>
              <option value="fit">Auto Fit Image</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">
              Orientation
            </label>
            <select
              value={orientation}
              onChange={(e: any) => setOrientation(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
            >
              <option value="portrait">Portrait</option>
              <option value="landscape">Landscape</option>
            </select>
          </div>
        </div>

        {/* PDF Quality & Watermark */}
        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-200 dark:border-slate-700">
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">
              PDF Quality
            </label>
            <select
              value={quality}
              onChange={(e: any) => setQuality(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
            >
              <option value="high">High (100% Crisp)</option>
              <option value="medium">Medium (80% Balanced)</option>
              <option value="low">Low (60% Compressed)</option>
            </select>
          </div>

          <div className="flex flex-col justify-end">
            <button
              onClick={() => setAddWatermark(!addWatermark)}
              className={`py-2 px-3 rounded-xl font-bold text-xs border transition-colors flex items-center justify-between ${
                addWatermark
                  ? "bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border-teal-500/50"
                  : "bg-slate-50 dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700"
              }`}
            >
              <span>Watermark</span>
              {addWatermark && <Check className="w-3.5 h-3.5 text-teal-500" />}
            </button>
          </div>
        </div>
      </div>

      {/* Page Manager Grid & Reordering */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
            Document Pages ({draftPages.length})
          </h4>

          <button
            onClick={startNewScan}
            className="flex items-center space-x-1 px-2.5 py-1 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-bold text-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Page</span>
          </button>
        </div>

        <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
          {draftPages.map((page, idx) => {
            const thumb = page.enhancedImage || page.croppedImage || page.originalImage;
            return (
              <div
                key={page.id}
                className="flex items-center justify-between p-2 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-12 rounded-lg bg-slate-200 dark:bg-slate-800 overflow-hidden shrink-0 border border-slate-300 dark:border-slate-700">
                    <img src={thumb} alt={`Page ${idx + 1}`} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <span className="text-xs font-extrabold text-slate-900 dark:text-white block">
                      Page {idx + 1}
                    </span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400">
                      Preset: {page.filters?.preset || "Original"}
                    </span>
                  </div>
                </div>

                <div className="flex items-center space-x-1">
                  <button
                    disabled={idx === 0}
                    onClick={() => reorderDraftPages(idx, idx - 1)}
                    className="p-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 disabled:opacity-30"
                    title="Move Up"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>

                  <button
                    disabled={idx === draftPages.length - 1}
                    onClick={() => reorderDraftPages(idx, idx + 1)}
                    className="p-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 disabled:opacity-30"
                    title="Move Down"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => deleteDraftPage(page.id)}
                    className="p-1.5 rounded-lg bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400"
                    title="Delete Page"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Export Action Buttons */}
      <div className="grid grid-cols-2 gap-2 pt-2">
        <button
          onClick={handleDownloadPDF}
          disabled={generating}
          className="py-3.5 px-4 rounded-2xl bg-teal-600 hover:bg-teal-500 text-white font-extrabold text-xs shadow-lg shadow-teal-600/20 flex items-center justify-center space-x-1.5"
        >
          {generating ? (
            <RefreshCw className="w-4 h-4 animate-spin" />
          ) : (
            <Download className="w-4 h-4" />
          )}
          <span>{generating ? "Building PDF..." : "Download PDF"}</span>
        </button>

        <button
          onClick={handleSharePDF}
          disabled={generating}
          className="py-3.5 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs shadow-lg shadow-indigo-600/20 flex items-center justify-center space-x-1.5"
        >
          <Share2 className="w-4 h-4" />
          <span>Share PDF</span>
        </button>
      </div>
    </div>
  );
};
