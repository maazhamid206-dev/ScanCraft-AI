import React, { useState, useEffect } from "react";
import {
  RotateCw,
  Sparkles,
  Maximize2,
  Check,
  ChevronLeft,
  ChevronRight,
  Trash2,
  Layers,
} from "lucide-react";
import { useDocument } from "../context/DocumentContext";
import { CornerPoints } from "../types";
import { autoDetectCornersFromImage, DEFAULT_CORNERS } from "../utils/imageProcessing";

export const CropPerspective: React.FC = () => {
  const {
    draftPages,
    activePageIndex,
    setActivePageIndex,
    updatePageCorners,
    setPageRotation,
    deleteDraftPage,
    setActiveTab,
  } = useDocument();

  const currentPage = draftPages[activePageIndex];

  const [corners, setCorners] = useState<CornerPoints>(
    currentPage?.corners || DEFAULT_CORNERS
  );
  const [activeCorner, setActiveCorner] = useState<keyof CornerPoints | null>(null);

  useEffect(() => {
    if (currentPage?.corners) {
      setCorners(currentPage.corners);
    }
  }, [currentPage]);

  if (!currentPage) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center h-80">
        <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
          No Scanned Document Loaded
        </p>
        <button
          onClick={() => setActiveTab("scanner")}
          className="mt-4 px-4 py-2 rounded-2xl bg-indigo-600 text-white font-bold text-xs"
        >
          Open Camera Scanner
        </button>
      </div>
    );
  }

  const handleCornerDrag = (
    cornerKey: keyof CornerPoints,
    e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>
  ) => {
    const container = (e.currentTarget.parentElement as HTMLElement)?.getBoundingClientRect();
    if (!container) return;

    const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
    const clientY = "touches" in e ? e.touches[0].clientY : e.clientY;

    const xPct = Math.max(0, Math.min(100, ((clientX - container.left) / container.width) * 100));
    const yPct = Math.max(0, Math.min(100, ((clientY - container.top) / container.height) * 100));

    const updated = {
      ...corners,
      [cornerKey]: { x: Math.round(xPct), y: Math.round(yPct) },
    };

    setCorners(updated);
    updatePageCorners(currentPage.id, updated);
  };

  const runAutoDetect = () => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const detected = autoDetectCornersFromImage(img);
      setCorners(detected);
      updatePageCorners(currentPage.id, detected);
    };
    img.src = currentPage.originalImage;
  };

  const handleRotate = () => {
    const nextRot = (currentPage.rotation + 90) % 360;
    setPageRotation(currentPage.id, nextRot);
  };

  const handleReset = () => {
    setCorners(DEFAULT_CORNERS);
    updatePageCorners(currentPage.id, DEFAULT_CORNERS);
  };

  return (
    <div className="flex flex-col space-y-4 pb-20 select-none">
      {/* Top Toolbar */}
      <div className="flex items-center justify-between bg-white dark:bg-slate-800 p-3 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
        <div className="flex items-center space-x-2">
          <button
            onClick={runAutoDetect}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 font-bold text-xs border border-teal-500/30 hover:bg-teal-100 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Auto Detect</span>
          </button>

          <button
            onClick={handleRotate}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-200 transition-colors"
            title="Rotate 90°"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          <button
            onClick={handleReset}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-200 transition-colors"
            title="Reset Corners"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>

        <button
          onClick={() => deleteDraftPage(currentPage.id)}
          className="p-2 rounded-xl bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 hover:bg-red-100 transition-colors"
          title="Delete Page"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Interactive Crop Canvas Viewport */}
      <div className="relative w-full aspect-[3/4] bg-slate-950 rounded-3xl overflow-hidden border border-slate-800 shadow-xl flex items-center justify-center">
        <img
          src={currentPage.originalImage}
          alt="Original Scan"
          className="w-full h-full object-contain pointer-events-none"
          style={{ transform: `rotate(${currentPage.rotation}deg)` }}
        />

        {/* Quadrilateral Overlay Lines */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <polygon
            points={`
              ${corners.topLeft.x}%,${corners.topLeft.y}%
              ${corners.topRight.x}%,${corners.topRight.y}%
              ${corners.bottomRight.x}%,${corners.bottomRight.y}%
              ${corners.bottomLeft.x}%,${corners.bottomLeft.y}%
            `}
            fill="rgba(20, 184, 166, 0.15)"
            stroke="#14b8a6"
            strokeWidth="2"
            strokeDasharray="4 4"
          />
        </svg>

        {/* Four Corner Drag Handles */}
        {(["topLeft", "topRight", "bottomRight", "bottomLeft"] as const).map((cornerKey) => {
          const pt = corners[cornerKey];
          return (
            <div
              key={cornerKey}
              style={{ left: `${pt.x}%`, top: `${pt.y}%` }}
              onMouseDown={(e) => {
                setActiveCorner(cornerKey);
                handleCornerDrag(cornerKey, e);
              }}
              onTouchStart={(e) => {
                setActiveCorner(cornerKey);
                handleCornerDrag(cornerKey, e);
              }}
              className="absolute -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-teal-400 border-2 border-white shadow-lg cursor-grab active:cursor-grabbing flex items-center justify-center z-20 hover:scale-125 transition-transform"
            >
              <div className="w-2.5 h-2.5 rounded-full bg-slate-950" />
            </div>
          );
        })}
      </div>

      {/* Page Selector Carousel if multi-page draft */}
      {draftPages.length > 1 && (
        <div className="flex items-center justify-between bg-white dark:bg-slate-800 p-2.5 rounded-2xl border border-slate-200 dark:border-slate-700">
          <button
            disabled={activePageIndex === 0}
            onClick={() => setActivePageIndex(activePageIndex - 1)}
            className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-700 disabled:opacity-30"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
            Page {activePageIndex + 1} of {draftPages.length}
          </span>

          <button
            disabled={activePageIndex === draftPages.length - 1}
            onClick={() => setActivePageIndex(activePageIndex + 1)}
            className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-700 disabled:opacity-30"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Apply Crop & Continue Button */}
      <button
        onClick={() => setActiveTab("enhancer")}
        className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-2xl shadow-lg shadow-indigo-600/30 flex items-center justify-center space-x-2 text-sm"
      >
        <span>Apply Crop & AI Enhance</span>
        <Check className="w-4 h-4" />
      </button>
    </div>
  );
};
