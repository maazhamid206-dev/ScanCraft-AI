import React, { useState } from "react";
import {
  Clock,
  Search,
  Trash2,
  FileText,
  ExternalLink,
  Layers,
  Filter,
  Grid as GridIcon,
  List as ListIcon,
} from "lucide-react";
import { useDocument } from "../context/DocumentContext";
import { SavedDocument } from "../types";

export const HistoryView: React.FC = () => {
  const { savedDocuments, deleteSavedDocument, loadSavedDocToDraft, startNewScan } =
    useDocument();

  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [viewMode, setViewMode] = useState<"list" | "grid">("list");

  const categories = ["All", "PDF Scan", "Receipt", "Invoice", "Urdu/Arabic", "Other"];

  const filteredDocs = savedDocuments.filter((doc) => {
    const matchesSearch =
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.category?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCat =
      selectedCategory === "All" ||
      doc.category?.toLowerCase() === selectedCategory.toLowerCase();

    return matchesSearch && matchesCat;
  });

  return (
    <div className="flex flex-col space-y-4 pb-20 select-none">
      {/* Search & Filter Header */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
              Scan History ({savedDocuments.length})
            </h3>
          </div>

          <div className="flex items-center space-x-1 bg-slate-100 dark:bg-slate-700 p-1 rounded-xl">
            <button
              onClick={() => setViewMode("list")}
              className={`p-1 rounded-lg transition-colors ${
                viewMode === "list"
                  ? "bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs"
                  : "text-slate-500"
              }`}
            >
              <ListIcon className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode("grid")}
              className={`p-1 rounded-lg transition-colors ${
                viewMode === "grid"
                  ? "bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs"
                  : "text-slate-500"
              }`}
            >
              <GridIcon className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search saved scans by title..."
            className="w-full pl-10 pr-4 py-2 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Category Chips */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-xl text-xs font-bold shrink-0 transition-colors ${
                selectedCategory === cat
                  ? "bg-indigo-600 text-white"
                  : "bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* History Documents List / Grid */}
      {filteredDocs.length === 0 ? (
        <div className="bg-white dark:bg-slate-800 rounded-3xl p-8 text-center border border-dashed border-slate-300 dark:border-slate-700">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto mb-3">
            <Layers className="w-6 h-6" />
          </div>
          <h4 className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
            No Scans Found
          </h4>
          <p className="text-[11px] text-slate-500 mt-1 max-w-xs mx-auto">
            {searchQuery
              ? `No scans matching "${searchQuery}".`
              : "Start scanning or importing documents to build your mobile history."}
          </p>
          <button
            onClick={startNewScan}
            className="mt-4 px-4 py-2 rounded-2xl bg-indigo-600 text-white font-extrabold text-xs"
          >
            Scan Document
          </button>
        </div>
      ) : viewMode === "list" ? (
        <div className="space-y-2.5">
          {filteredDocs.map((doc) => {
            const thumb = doc.pages?.[0]?.enhancedImage || doc.pages?.[0]?.croppedImage;
            return (
              <div
                key={doc.id}
                className="bg-white dark:bg-slate-800 rounded-2xl p-3 border border-slate-200 dark:border-slate-700 flex items-center justify-between shadow-xs hover:border-indigo-500 transition-colors"
              >
                <div
                  onClick={() => loadSavedDocToDraft(doc)}
                  className="flex items-center space-x-3 flex-1 min-w-0 cursor-pointer"
                >
                  <div className="w-12 h-14 rounded-xl bg-slate-100 dark:bg-slate-700 overflow-hidden shrink-0 border border-slate-200 dark:border-slate-600">
                    {thumb ? (
                      <img src={thumb} alt={doc.title} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-400">
                        <FileText className="w-5 h-5" />
                      </div>
                    )}
                  </div>

                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {doc.title}
                    </h4>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                      {new Date(doc.createdAt).toLocaleDateString()} &bull; {doc.pages?.length || 1}{" "}
                      Pages
                    </p>
                    <span className="inline-block mt-1 text-[9px] font-semibold px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300">
                      {doc.category || "Document"}
                    </span>
                  </div>
                </div>

                <div className="flex items-center space-x-1 pl-2">
                  <button
                    onClick={() => loadSavedDocToDraft(doc)}
                    className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
                    title="Open in Editor"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => deleteSavedDocument(doc.id)}
                    className="p-2 rounded-xl bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 hover:bg-red-100 transition-colors"
                    title="Delete Scan"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {filteredDocs.map((doc) => {
            const thumb = doc.pages?.[0]?.enhancedImage || doc.pages?.[0]?.croppedImage;
            return (
              <div
                key={doc.id}
                className="bg-white dark:bg-slate-800 rounded-3xl p-3 border border-slate-200 dark:border-slate-700 flex flex-col justify-between shadow-xs hover:border-indigo-500 transition-colors"
              >
                <div
                  onClick={() => loadSavedDocToDraft(doc)}
                  className="space-y-2 cursor-pointer"
                >
                  <div className="w-full aspect-[3/4] rounded-2xl bg-slate-100 dark:bg-slate-700 overflow-hidden border border-slate-200 dark:border-slate-600">
                    {thumb ? (
                      <img src={thumb} alt={doc.title} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-400">
                        <FileText className="w-8 h-8" />
                      </div>
                    )}
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {doc.title}
                    </h4>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      {doc.pages?.length || 1} pgs &bull;{" "}
                      {new Date(doc.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-700 mt-2">
                  <button
                    onClick={() => loadSavedDocToDraft(doc)}
                    className="text-[10px] font-extrabold text-indigo-600 dark:text-indigo-400"
                  >
                    Open
                  </button>
                  <button
                    onClick={() => deleteSavedDocument(doc.id)}
                    className="text-red-500 hover:text-red-600 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
