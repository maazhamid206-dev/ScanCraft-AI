import React from "react";
import { Home, Camera, FileText, Clock, Settings } from "lucide-react";
import { useDocument } from "../context/DocumentContext";
import { ActiveTab } from "../types";

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, draftPages } = useDocument();

  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: "home", label: "Home", icon: <Home className="w-5 h-5" /> },
    { id: "scanner", label: "Scan", icon: <Camera className="w-5 h-5" /> },
    {
      id: "pdf_creator",
      label: "PDF",
      icon: <FileText className="w-5 h-5" />,
      badge: draftPages.length > 0 ? draftPages.length : undefined,
    },
    { id: "history", label: "History", icon: <Clock className="w-5 h-5" /> },
    { id: "settings", label: "Settings", icon: <Settings className="w-5 h-5" /> },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 pb-safe transition-colors">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-around">
        {navItems.map((item) => {
          const isActive =
            activeTab === item.id ||
            (item.id === "scanner" && (activeTab === "crop" || activeTab === "enhancer" || activeTab === "ocr"));

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className="relative flex flex-col items-center justify-center py-1 px-3 group"
            >
              <div
                className={`relative px-4 py-1.5 rounded-full transition-all duration-200 flex items-center justify-center ${
                  isActive
                    ? "bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold"
                    : "text-slate-500 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-white"
                }`}
              >
                {item.icon}

                {item.badge !== undefined && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-teal-500 text-slate-950 font-extrabold text-[10px] flex items-center justify-center shadow-sm">
                    {item.badge}
                  </span>
                )}
              </div>
              <span
                className={`text-[11px] mt-0.5 transition-colors ${
                  isActive
                    ? "text-indigo-700 dark:text-indigo-300 font-semibold"
                    : "text-slate-500 dark:text-slate-400"
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
