import React, { useEffect, useState } from "react";
import { Sparkles, Scan, ArrowRight } from "lucide-react";
import { motion } from "motion/react";

interface SplashProps {
  onFinish: () => void;
}

export const Splash: React.FC<SplashProps> = ({ onFinish }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        return prev + 20;
      });
    }, 250);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-950 text-white p-8 select-none">
      <div className="w-full max-w-sm flex justify-end">
        <span className="text-xs font-semibold px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
          v2.5 Android M3
        </span>
      </div>

      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="flex flex-col items-center text-center space-y-6"
      >
        <div className="relative">
          <div className="w-28 h-28 rounded-3xl bg-gradient-to-br from-indigo-500 via-purple-600 to-indigo-700 flex items-center justify-center shadow-2xl shadow-indigo-500/40 border border-indigo-400/30">
            <Scan className="w-14 h-14 text-white animate-pulse" />
          </div>
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 12, ease: "linear" }}
            className="absolute -top-2 -right-2 w-10 h-10 rounded-full bg-teal-500 flex items-center justify-center text-slate-950 font-bold shadow-lg"
          >
            <Sparkles className="w-5 h-5 text-slate-950" />
          </motion.div>
        </div>

        <div>
          <h1 className="text-4xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-indigo-100 to-indigo-300">
            ScanCraft AI
          </h1>
          <p className="text-indigo-200/80 text-sm mt-2 max-w-xs font-medium">
            Intelligent Mobile Document Scanner, Edge Crop, AI Restoration & Multilingual OCR
          </p>
        </div>
      </motion.div>

      <div className="w-full max-w-xs space-y-4">
        <div className="w-full bg-slate-800/80 h-2 rounded-full overflow-hidden border border-slate-700/50">
          <div
            className="bg-gradient-to-r from-indigo-500 to-teal-400 h-full transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>

        <button
          onClick={onFinish}
          className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 active:scale-98 transition-all font-semibold text-white shadow-lg shadow-indigo-600/30 flex items-center justify-center space-x-2 text-sm"
        >
          <span>Open Scanner</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <p className="text-center text-[11px] text-slate-400">
          Powered by Gemini Vision AI &bull; English, Urdu & Arabic OCR Supported
        </p>
      </div>
    </div>
  );
};
