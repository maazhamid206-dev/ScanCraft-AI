import React from "react";
import {
  Settings,
  Sun,
  Moon,
  Laptop,
  Image as ImageIcon,
  FileText,
  Languages,
  Zap,
  Award,
  Trash2,
  Check,
  ShieldCheck,
  Smartphone,
  Cloud,
  User,
  LogOut,
  LogIn,
} from "lucide-react";
import { useTheme } from "../context/ThemeContext";
import { useDocument } from "../context/DocumentContext";
import { useAdMob } from "../context/AdMobContext";
import { useAuth } from "../context/AuthContext";
import { OCRLanguage, ThemeMode } from "../types";

export const SettingsView: React.FC = () => {
  const { theme, setTheme } = useTheme();
  const { settings, updateSettings, savedDocuments } = useDocument();
  const { rewardPoints, showRewarded, showInterstitial } = useAdMob();
  const { userProfile, isGuest, setShowAuthModal, logout } = useAuth();

  const handleClearHistory = () => {
    if (confirm("Are you sure you want to clear all saved scan history?")) {
      localStorage.removeItem("scancraft_history");
      window.location.reload();
    }
  };

  return (
    <div className="flex flex-col space-y-4 pb-20 select-none">
      {/* App Header & Pro Badge */}
      <div className="bg-gradient-to-r from-indigo-900 to-slate-900 text-white p-5 rounded-3xl border border-indigo-700/50 shadow-md">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-extrabold text-base">ScanCraft AI v2.5</h3>
            <p className="text-xs text-indigo-200">
              Android Material 3 Production Architecture
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between mt-4 pt-3 border-t border-indigo-800/80">
          <div className="flex items-center space-x-1.5 text-xs text-amber-300 font-bold">
            <Award className="w-4 h-4" />
            <span>{rewardPoints} AI Credits Available</span>
          </div>

          <button
            onClick={() => showRewarded()}
            className="px-3 py-1 bg-amber-400 text-slate-950 font-extrabold rounded-xl text-xs hover:brightness-110"
          >
            Earn +5 Credits
          </button>
        </div>
      </div>

      {/* Firebase Account & Cloud Sync Section */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider flex items-center space-x-2">
            <Cloud className="w-4 h-4 text-indigo-500" />
            <span>Firebase Backend & Sync</span>
          </h4>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
            Firestore Connected
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-indigo-600 text-white font-extrabold flex items-center justify-center text-sm shadow-md overflow-hidden">
              {userProfile?.profilePhoto ? (
                <img src={userProfile.profilePhoto} alt={userProfile.fullName} className="w-full h-full object-cover" />
              ) : userProfile && !isGuest ? (
                userProfile.fullName.charAt(0).toUpperCase()
              ) : (
                <User className="w-5 h-5" />
              )}
            </div>
            <div>
              <h5 className="font-extrabold text-xs text-slate-900 dark:text-white">
                {userProfile ? userProfile.fullName : "Guest Session"}
              </h5>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                {isGuest ? "Not signed in to permanent account" : userProfile?.email}
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowAuthModal(true)}
            className="px-3 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-500 transition-colors"
          >
            {userProfile && !isGuest ? "Manage Account" : "Sign In"}
          </button>
        </div>

        <p className="text-[11px] text-slate-500 dark:text-slate-400">
          Cloud Firestore synchronizes document metadata, OCR extractions, and scan history with Firebase Storage image backing.
        </p>
      </div>

      {/* 1. Theme Preferences */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-3">
        <h4 className="text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider flex items-center space-x-2">
          <Sun className="w-4 h-4 text-amber-500" />
          <span>App Appearance</span>
        </h4>

        <div className="grid grid-cols-3 gap-2">
          {[
            { id: "light", label: "Light", icon: <Sun className="w-4 h-4 text-amber-500" /> },
            { id: "dark", label: "Dark", icon: <Moon className="w-4 h-4 text-indigo-400" /> },
            { id: "system", label: "System", icon: <Laptop className="w-4 h-4 text-teal-500" /> },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setTheme(item.id as ThemeMode)}
              className={`p-3 rounded-2xl border flex flex-col items-center space-y-1.5 transition-all ${
                theme === item.id
                  ? "bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border-indigo-500 font-bold shadow-xs"
                  : "bg-slate-50 dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700"
              }`}
            >
              {item.icon}
              <span className="text-xs">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 2. Image & PDF Quality */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-3">
        <h4 className="text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider flex items-center space-x-2">
          <ImageIcon className="w-4 h-4 text-indigo-500" />
          <span>Quality & Compression</span>
        </h4>

        <div className="space-y-2">
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">
              Camera Scan Resolution
            </label>
            <select
              value={settings.imageQuality}
              onChange={(e: any) => updateSettings({ imageQuality: e.target.value })}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
            >
              <option value="high">High Resolution (100% Uncompressed)</option>
              <option value="medium">Medium (80% Optimized)</option>
              <option value="low">Low (60% Compact)</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">
              Default PDF Export Quality
            </label>
            <select
              value={settings.pdfQuality}
              onChange={(e: any) => updateSettings({ pdfQuality: e.target.value })}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
            >
              <option value="high">High Quality (Lossless PDF)</option>
              <option value="medium">Balanced PDF</option>
              <option value="low">Compact PDF File</option>
            </select>
          </div>
        </div>
      </div>

      {/* 3. Multilingual OCR Defaults */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-3">
        <h4 className="text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider flex items-center space-x-2">
          <Languages className="w-4 h-4 text-teal-500" />
          <span>Multilingual OCR Defaults</span>
        </h4>

        <div>
          <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">
            Default Text Recognition Language
          </label>
          <select
            value={settings.defaultLanguage}
            onChange={(e: any) => updateSettings({ defaultLanguage: e.target.value as OCRLanguage })}
            className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
          >
            <option value="Auto">Auto Detect Language</option>
            <option value="English">English</option>
            <option value="Urdu">Urdu (اردو)</option>
            <option value="Arabic">Arabic (العربية)</option>
          </select>
        </div>
      </div>

      {/* 4. Google AdMob Integration Test & Demo */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider flex items-center space-x-2">
            <Zap className="w-4 h-4 text-amber-500" />
            <span>Google AdMob Integration</span>
          </h4>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
            Ready
          </span>
        </div>

        <p className="text-[11px] text-slate-500 dark:text-slate-400">
          Clean decoupled AdMob architecture configured for Banner, Interstitial, and Rewarded Ads.
        </p>

        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={() => showInterstitial()}
            className="py-2.5 px-3 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold text-xs border border-indigo-200 dark:border-indigo-800"
          >
            Test Interstitial Ad
          </button>
          <button
            onClick={() => showRewarded()}
            className="py-2.5 px-3 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 font-bold text-xs border border-amber-200 dark:border-amber-800"
          >
            Test Rewarded Ad
          </button>
        </div>
      </div>

      {/* 5. Storage & Reset */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider">
            Data & Storage
          </h4>
          <span className="text-xs text-slate-500">Saved: {savedDocuments.length} docs</span>
        </div>

        <button
          onClick={handleClearHistory}
          className="w-full py-3 rounded-2xl bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 font-bold text-xs hover:bg-red-100 transition-colors flex items-center justify-center space-x-1.5"
        >
          <Trash2 className="w-4 h-4" />
          <span>Clear All Scan History</span>
        </button>
      </div>
    </div>
  );
};
