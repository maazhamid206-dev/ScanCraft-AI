import React, { useState, useEffect } from "react";
import {
  FileText,
  Copy,
  Check,
  Volume2,
  VolumeX,
  Download,
  Languages,
  Sparkles,
  RefreshCcw,
  Globe,
  Share2,
} from "lucide-react";
import { useDocument } from "../context/DocumentContext";
import { OCRData, OCRLanguage } from "../types";

export const OcrView: React.FC = () => {
  const { draftPages, activePageIndex, settings } = useDocument();

  const currentPage = draftPages[activePageIndex];

  const [targetLanguage, setTargetLanguage] = useState<OCRLanguage>(
    settings.defaultLanguage || "Auto"
  );
  const [ocrLoading, setOcrLoading] = useState<boolean>(false);
  const [ocrResult, setOcrResult] = useState<OCRData | null>(
    currentPage?.ocrResult || null
  );
  const [editableText, setEditableText] = useState<string>(
    currentPage?.ocrResult?.text || ""
  );
  const [copied, setCopied] = useState<boolean>(false);
  const [speaking, setSpeaking] = useState<boolean>(false);

  useEffect(() => {
    if (currentPage?.ocrResult) {
      setOcrResult(currentPage.ocrResult);
      setEditableText(currentPage.ocrResult.text);
    } else if (currentPage && !ocrResult) {
      runOcrRecognition();
    }
  }, [currentPage]);

  if (!currentPage) {
    return (
      <div className="p-8 text-center text-slate-500">
        <p>No document page loaded for OCR.</p>
      </div>
    );
  }

  const runOcrRecognition = async () => {
    setOcrLoading(true);
    try {
      const res = await fetch("/api/ocr", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: currentPage.enhancedImage || currentPage.croppedImage || currentPage.originalImage,
          targetLanguage,
        }),
      });

      const data = await res.json();
      if (data.success && data.result) {
        const r: OCRData = {
          text: data.result.text || "",
          detectedLanguage: data.result.detectedLanguage || targetLanguage,
          confidenceScore: data.result.confidenceScore || 95,
          documentType: data.result.documentType || "Document",
          wordCount: data.result.wordCount || 0,
          keyDetails: data.result.keyDetails || [],
          englishTranslation: data.result.englishTranslation || "",
          extractedAt: new Date().toLocaleTimeString(),
        };
        setOcrResult(r);
        setEditableText(r.text);
      }
    } catch (err) {
      console.error("OCR Recognition Error:", err);
    } finally {
      setOcrLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(editableText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadTextFile = () => {
    const blob = new Blob([editableText], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `OCR_Extracted_${targetLanguage}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const toggleSpeech = () => {
    if (!("speechSynthesis" in window)) return;

    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }

    if (!editableText) return;

    const utterance = new SpeechSynthesisUtterance(editableText);
    if (targetLanguage === "Urdu") {
      utterance.lang = "ur-PK";
    } else if (targetLanguage === "Arabic") {
      utterance.lang = "ar-SA";
    } else {
      utterance.lang = "en-US";
    }

    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setSpeaking(true);
  };

  const isRtl =
    ocrResult?.detectedLanguage === "Urdu" ||
    ocrResult?.detectedLanguage === "Arabic" ||
    targetLanguage === "Urdu" ||
    targetLanguage === "Arabic";

  return (
    <div className="flex flex-col space-y-4 pb-20 select-none">
      {/* Top OCR Config Header */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Languages className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
              Multilingual AI OCR
            </h3>
          </div>

          <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300">
            Gemini 3.6 Flash
          </span>
        </div>

        {/* Language Selector Tabs */}
        <div className="grid grid-cols-4 gap-1.5 p-1 bg-slate-100 dark:bg-slate-700/60 rounded-2xl">
          {(["Auto", "English", "Urdu", "Arabic"] as OCRLanguage[]).map((lang) => (
            <button
              key={lang}
              onClick={() => {
                setTargetLanguage(lang);
              }}
              className={`py-1.5 text-xs font-bold rounded-xl transition-colors ${
                targetLanguage === lang
                  ? "bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs"
                  : "text-slate-600 dark:text-slate-300 hover:text-slate-900"
              }`}
            >
              {lang === "Urdu" ? "Urdu (اردو)" : lang === "Arabic" ? "Arabic (عربي)" : lang}
            </button>
          ))}
        </div>

        <button
          onClick={runOcrRecognition}
          disabled={ocrLoading}
          className="w-full py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs shadow-md shadow-indigo-600/20 flex items-center justify-center space-x-1.5"
        >
          {ocrLoading ? (
            <RefreshCcw className="w-4 h-4 animate-spin" />
          ) : (
            <Sparkles className="w-4 h-4" />
          )}
          <span>{ocrLoading ? "Extracting Text..." : "Re-Run Text Recognition"}</span>
        </button>
      </div>

      {/* Extracted Text Content Card */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
          <div className="flex items-center space-x-2">
            <Globe className="w-4 h-4 text-teal-500" />
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
              Extracted Text Result
            </span>
          </div>

          <div className="flex items-center space-x-1">
            <button
              onClick={toggleSpeech}
              className={`p-1.5 rounded-lg transition-colors ${
                speaking
                  ? "bg-amber-500 text-slate-950 font-bold"
                  : "bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
              }`}
              title="Text-to-Speech playback"
            >
              {speaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            <button
              onClick={copyToClipboard}
              className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 transition-colors"
              title="Copy Text"
            >
              {copied ? (
                <Check className="w-4 h-4 text-teal-500" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>

            <button
              onClick={downloadTextFile}
              className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 transition-colors"
              title="Download TXT"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>

        {ocrLoading ? (
          <div className="py-12 text-center text-slate-400 space-y-2">
            <RefreshCcw className="w-8 h-8 animate-spin mx-auto text-indigo-500" />
            <p className="text-xs font-bold">Extracting script & text layout with Gemini Vision...</p>
          </div>
        ) : (
          <textarea
            value={editableText}
            onChange={(e) => setEditableText(e.target.value)}
            dir={isRtl ? "rtl" : "ltr"}
            rows={10}
            className={`w-full p-3 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-sans ${
              isRtl ? "text-right font-semibold" : "text-left"
            }`}
            placeholder="Extracted text will appear here..."
          />
        )}

        {ocrResult && (
          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
            <span>
              Lang: <b>{ocrResult.detectedLanguage}</b> &bull; Accuracy:{" "}
              <b>{ocrResult.confidenceScore}%</b>
            </span>
            <span>Words: {editableText.split(/\s+/).filter(Boolean).length}</span>
          </div>
        )}
      </div>

      {/* English Translation Panel if Urdu or Arabic detected */}
      {ocrResult?.englishTranslation && (
        <div className="bg-teal-50 dark:bg-teal-950/40 p-4 rounded-3xl border border-teal-200 dark:border-teal-800 space-y-2">
          <h4 className="text-xs font-bold text-teal-900 dark:text-teal-200 flex items-center space-x-1.5">
            <Globe className="w-4 h-4 text-teal-600" />
            <span>AI English Translation</span>
          </h4>
          <p className="text-xs text-teal-950 dark:text-teal-100 leading-relaxed font-medium">
            {ocrResult.englishTranslation}
          </p>
        </div>
      )}
    </div>
  );
};
