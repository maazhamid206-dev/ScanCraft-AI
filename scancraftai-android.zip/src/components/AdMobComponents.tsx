/**
 * AdMobComponents.tsx
 *
 * Native Android (Capacitor): the real AdMob SDK renders ads as native overlays.
 * - Banner:       AdMobBannerAd renders a padding spacer so content isn't hidden under the native banner.
 * - Interstitial/Rewarded: AdMobAdModals renders nothing — the native SDK takes over full-screen.
 *
 * Web preview (Replit / browser): mock UI is shown so the app remains fully testable.
 */

import React, { useState, useEffect } from "react";
import { X, Sparkles, Award, Play } from "lucide-react";
import { useAdMob } from "../context/AdMobContext";

// ─── Banner ───────────────────────────────────────────────────────────────────

export const AdMobBannerAd: React.FC<{ placement?: "top" | "bottom" }> = ({
  placement = "bottom",
}) => {
  const { isNative } = useAdMob();
  const [closed, setClosed] = useState(false);

  // On native Android: the real banner is rendered as a native overlay by the SDK.
  // We just add a spacer so app content isn't hidden underneath the 50–90 px banner.
  if (isNative) {
    return (
      <div
        aria-hidden="true"
        style={{ height: 60 }}
        className={placement === "top" ? "mb-3" : "mt-3"}
      />
    );
  }

  // ── Web fallback mock banner ─────────────────────────────────────────────────
  if (closed) return null;

  return (
    <div
      className={`w-full max-w-md mx-auto my-2 px-3 py-2 bg-gradient-to-r from-slate-100 via-indigo-50/50 to-slate-100 dark:from-slate-800 dark:via-indigo-950/40 dark:to-slate-800 border border-slate-200 dark:border-slate-700/60 rounded-xl flex items-center justify-between shadow-sm select-none ${
        placement === "top" ? "mb-3" : "mt-3"
      }`}
    >
      <div className="flex items-center space-x-2.5">
        <span className="text-[10px] font-bold tracking-wider uppercase px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/30">
          AD
        </span>
        <div className="text-xs">
          <p className="font-semibold text-slate-800 dark:text-slate-200">
            ScanCraft AI Pro Upgrade
          </p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">
            Unlimited High-Res PDF &amp; Multilingual AI OCR
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-1">
        <span className="px-2.5 py-1 text-[11px] font-bold text-white bg-indigo-600 rounded-lg shadow-sm">
          GET PRO
        </span>
        <button
          onClick={() => setClosed(true)}
          className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full"
          aria-label="Close Ad"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};

// ─── Full-screen ad modals (web-only fallback) ────────────────────────────────

export const AdMobAdModals: React.FC = () => {
  const { isNative, activeAdModal, dismissAdModal } = useAdMob();
  const [secondsLeft, setSecondsLeft] = useState(5);

  // Hooks must be called unconditionally — guard inside the effect instead
  useEffect(() => {
    // On native, or when no modal is active, nothing to do
    if (isNative || !activeAdModal) return;

    setSecondsLeft(5);
    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isNative, activeAdModal]);

  // On native the SDK handles full-screen ads entirely — nothing to render here.
  if (isNative) return null;

  if (!activeAdModal) return null;

  const isRewarded = activeAdModal === "rewarded";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 select-none">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 text-white rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between w-full border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
              Google AdMob {isRewarded ? "Rewarded Ad" : "Interstitial Ad"}
            </span>
          </div>

          <button
            onClick={secondsLeft === 0 ? dismissAdModal : undefined}
            disabled={secondsLeft > 0}
            className={`px-3 py-1 text-xs font-bold rounded-full transition-all ${
              secondsLeft === 0
                ? "bg-slate-700 text-white hover:bg-slate-600 cursor-pointer"
                : "bg-slate-800 text-slate-500 cursor-not-allowed"
            }`}
          >
            {secondsLeft > 0 ? `Skip in ${secondsLeft}s` : "Close Ad ✕"}
          </button>
        </div>

        {/* Icon */}
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
          {isRewarded ? (
            <Award className="w-10 h-10 text-amber-300 animate-bounce" />
          ) : (
            <Play className="w-10 h-10 text-white animate-pulse" />
          )}
        </div>

        {/* Copy */}
        <div>
          <h3 className="text-lg font-bold">
            {isRewarded
              ? "Watch Ad to Earn +5 Free AI Credits"
              : "ScanCraft AI Sponsor Message"}
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            {isRewarded
              ? "Watch this brief 5-second video ad to instantly unlock premium AI document enhancement & translation features!"
              : "Thank you for using ScanCraft AI. Real AdMob ads are active for Google Play Store deployment."}
          </p>
        </div>

        {/* Ad Unit info */}
        <div className="w-full bg-slate-800 rounded-2xl p-4 border border-slate-700/50 flex flex-col items-center space-y-2">
          <div className="flex items-center space-x-2 text-indigo-400 text-xs font-semibold">
            <Sparkles className="w-4 h-4" />
            <span>
              {isRewarded
                ? "Rewarded Ad — ca-app-pub-1729431496616324/4662087701"
                : "Interstitial Ad — ca-app-pub-1729431496616324/2789622897"}
            </span>
          </div>
          <p className="text-[11px] text-slate-400">
            Real AdMob SDK active on Android. Web preview shows this mock UI.
          </p>
        </div>

        {/* CTA */}
        {secondsLeft === 0 && (
          <button
            onClick={dismissAdModal}
            className="w-full py-3 bg-gradient-to-r from-indigo-500 to-teal-400 text-slate-950 font-extrabold rounded-2xl shadow-lg hover:brightness-110 active:scale-98 transition-all text-sm"
          >
            {isRewarded ? "Claim +5 AI Credits Now!" : "Continue to App"}
          </button>
        )}
      </div>
    </div>
  );
};
