import React, { useState } from "react";
import {
  Sparkles,
  Sliders,
  FileText,
  Save,
  Wand2,
  RefreshCcw,
  Check,
  ChevronRight,
  Sun,
  Moon,
  Zap,
} from "lucide-react";
import { useDocument } from "../context/DocumentContext";
import { useAdMob } from "../context/AdMobContext";
import { FilterSettings } from "../types";
import { DEFAULT_FILTERS } from "../utils/imageProcessing";

export const EnhancerView: React.FC = () => {
  const {
    draftPages,
    activePageIndex,
    updatePageFilter,
    saveDraftToHistory,
    setActiveTab,
  } = useDocument();

  const { showRewarded } = useAdMob();

  const currentPage = draftPages[activePageIndex];

  const [sliderPos, setSliderPos] = useState<number>(50); // 0 to 100 split view
  const [showSliders, setShowSliders] = useState<boolean>(false);
  const [analyzingAi, setAnalyzingAi] = useState<boolean>(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<any>(null);

  if (!currentPage) {
    return (
      <div className="p-8 text-center text-slate-500">
        <p>No document page selected.</p>
        <button
          onClick={() => setActiveTab("scanner")}
          className="mt-4 px-4 py-2 bg-indigo-600 text-white font-bold rounded-2xl text-xs"
        >
          Scan a Document
        </button>
      </div>
    );
  }

  const currentFilters = currentPage.filters || DEFAULT_FILTERS;

  const setPreset = (presetName: FilterSettings["preset"]) => {
    const updated: FilterSettings = {
      ...currentFilters,
      preset: presetName,
    };
    updatePageFilter(currentPage.id, updated);
  };

  const handleSliderChange = (key: keyof FilterSettings, value: number) => {
    const updated: FilterSettings = {
      ...currentFilters,
      [key]: value,
    };
    updatePageFilter(currentPage.id, updated);
  };

  const runGeminiAiEnhance = async () => {
    setAnalyzingAi(true);
    try {
      const res = await fetch("/api/enhance-ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: currentPage.croppedImage || currentPage.originalImage,
        }),
      });
      const data = await res.json();
      if (data.success && data.result) {
        setAiAnalysisResult(data.result);
        const r = data.result;

        const updated: FilterSettings = {
          preset: r.recommendedPreset === "Color Enhance" ? "color_enhance" : "magic_bw",
          brightness: r.brightnessAdjustment || 10,
          contrast: r.contrastAdjustment || 20,
          sharpness: r.sharpnessAmount || 35,
          shadowRemoval: r.shadowRemovalStrength || 50,
          noiseReduction: r.noiseReductionLevel || 20,
          bwThreshold: 128,
        };
        updatePageFilter(currentPage.id, updated);
      }
    } catch (err) {
      console.warn("AI Enhance error:", err);
    } finally {
      setAnalyzingAi(false);
    }
  };

  const presets: { id: FilterSettings["preset"]; label: string; icon: string }[] = [
    { id: "magic_bw", label: "Magic B&W", icon: "✨" },
    { id: "color_enhance", label: "Color Mode", icon: "🎨" },
    { id: "sharpen", label: "Sharpen Text", icon: "✏️" },
    { id: "shadow_remove", label: "Remove Shadows", icon: "☀️" },
    { id: "original", label: "Original", icon: "📷" },
  ];

  return (
    <div className="flex flex-col space-y-4 pb-20 select-none">
      {/* Top AI Auto Restoration Banner */}
      <div className="flex items-center justify-between bg-gradient-to-r from-indigo-900 to-purple-900 text-white p-3 rounded-2xl shadow-md border border-indigo-700/50">
        <div className="flex items-center space-x-2">
          <Wand2 className="w-5 h-5 text-teal-400 animate-pulse" />
          <div>
            <h4 className="text-xs font-extrabold">Gemini AI Document Restoration</h4>
            <p className="text-[10px] text-indigo-200">
              Auto-detects blur, shadows & optimizes text contrast
            </p>
          </div>
        </div>

        <button
          onClick={runGeminiAiEnhance}
          disabled={analyzingAi}
          className="px-3 py-1.5 rounded-xl bg-teal-400 text-slate-950 font-extrabold text-xs shadow-sm hover:brightness-110 active:scale-95 transition-all flex items-center space-x-1"
        >
          {analyzingAi ? (
            <RefreshCcw className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Sparkles className="w-3.5 h-3.5" />
          )}
          <span>{analyzingAi ? "Restoring..." : "AI Auto"}</span>
        </button>
      </div>

      {aiAnalysisResult && (
        <div className="bg-indigo-50 dark:bg-indigo-950/60 p-3 rounded-xl border border-indigo-200 dark:border-indigo-800 text-xs">
          <p className="font-bold text-indigo-900 dark:text-indigo-200">
            AI Diagnosis: {aiAnalysisResult.documentSummary || "Restoration applied"}
          </p>
          <p className="text-[11px] text-indigo-700 dark:text-indigo-300 mt-0.5">
            Recommended Preset: {aiAnalysisResult.recommendedPreset || "Magic B&W"} &bull; Quality
            Score: {aiAnalysisResult.qualityScore || 90}%
          </p>
        </div>
      )}

      {/* ORIGINAL vs ENHANCED COMPARISON SLIDER STAGE */}
      <div className="relative w-full aspect-[3/4] bg-slate-950 rounded-3xl overflow-hidden border border-slate-800 shadow-xl select-none">
        {/* Under layer: Enhanced Image */}
        <img
          src={currentPage.enhancedImage || currentPage.croppedImage}
          alt="Enhanced Scan"
          className="absolute inset-0 w-full h-full object-contain"
        />

        {/* Top clipped layer: Original Image */}
        <div
          className="absolute inset-0 overflow-hidden border-r-2 border-amber-400 shadow-xl"
          style={{ width: `${sliderPos}%` }}
        >
          <img
            src={currentPage.originalImage}
            alt="Original Photo"
            className="w-full h-full object-contain max-w-none"
            style={{ width: "100%", height: "100%" }}
          />
          <span className="absolute top-3 left-3 bg-slate-900/80 text-white text-[10px] font-bold px-2 py-1 rounded-md border border-slate-700">
            ORIGINAL
          </span>
        </div>

        <span className="absolute top-3 right-3 bg-indigo-600/90 text-white text-[10px] font-bold px-2 py-1 rounded-md border border-indigo-400 shadow-sm">
          ENHANCED SCAN
        </span>

        {/* Interactive Split Drag Handle */}
        <input
          type="range"
          min="0"
          max="100"
          value={sliderPos}
          onChange={(e) => setSliderPos(Number(e.target.value))}
          className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-30"
        />

        {/* Visual Handle Bar */}
        <div
          className="absolute top-0 bottom-0 w-1 bg-amber-400 pointer-events-none z-20 flex items-center justify-center"
          style={{ left: `${sliderPos}%` }}
        >
          <div className="w-7 h-7 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center font-bold text-[10px] shadow-lg">
            &harr;
          </div>
        </div>
      </div>

      <p className="text-center text-[11px] text-slate-500">
        Drag slider left or right to compare Original vs Enhanced Scan
      </p>

      {/* PRESET FILTER BUTTONS */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 no-scrollbar">
        {presets.map((p) => {
          const isSelected = currentFilters.preset === p.id;
          return (
            <button
              key={p.id}
              onClick={() => setPreset(p.id)}
              className={`px-3.5 py-2 rounded-2xl font-bold text-xs shrink-0 transition-all flex items-center space-x-1.5 ${
                isSelected
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20"
                  : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700"
              }`}
            >
              <span>{p.icon}</span>
              <span>{p.label}</span>
            </button>
          );
        })}

        <button
          onClick={() => setShowSliders(!showSliders)}
          className={`px-3.5 py-2 rounded-2xl font-bold text-xs shrink-0 transition-all flex items-center space-x-1.5 ${
            showSliders
              ? "bg-purple-600 text-white"
              : "bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200"
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Tune</span>
        </button>
      </div>

      {/* MANUAL TUNING SLIDERS PANEL */}
      {showSliders && (
        <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-3">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 border-b border-slate-200 dark:border-slate-700 pb-2">
            Fine-Tuning Controls
          </h4>

          {/* Brightness */}
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
              <span>Brightness</span>
              <span>{currentFilters.brightness}</span>
            </div>
            <input
              type="range"
              min="-100"
              max="100"
              value={currentFilters.brightness}
              onChange={(e) => handleSliderChange("brightness", Number(e.target.value))}
              className="w-full accent-indigo-600"
            />
          </div>

          {/* Contrast */}
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
              <span>Contrast</span>
              <span>{currentFilters.contrast}</span>
            </div>
            <input
              type="range"
              min="-100"
              max="100"
              value={currentFilters.contrast}
              onChange={(e) => handleSliderChange("contrast", Number(e.target.value))}
              className="w-full accent-indigo-600"
            />
          </div>

          {/* Shadow Removal */}
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
              <span>Shadow Removal</span>
              <span>{currentFilters.shadowRemoval}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={currentFilters.shadowRemoval}
              onChange={(e) => handleSliderChange("shadowRemoval", Number(e.target.value))}
              className="w-full accent-indigo-600"
            />
          </div>

          {/* Sharpness */}
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
              <span>Text Sharpness</span>
              <span>{currentFilters.sharpness}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={currentFilters.sharpness}
              onChange={(e) => handleSliderChange("sharpness", Number(e.target.value))}
              className="w-full accent-indigo-600"
            />
          </div>
        </div>
      )}

      {/* QUICK ACTION NAVIGATION BUTTONS */}
      <div className="grid grid-cols-2 gap-2 pt-2">
        <button
          onClick={() => setActiveTab("ocr")}
          className="py-3 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center space-x-1.5 shadow-md shadow-indigo-600/20"
        >
          <FileText className="w-4 h-4" />
          <span>OCR Text Recognition</span>
        </button>

        <button
          onClick={() => setActiveTab("pdf_creator")}
          className="py-3 px-4 rounded-2xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center justify-center space-x-1.5 shadow-md shadow-teal-600/20"
        >
          <span>Create PDF Document</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <button
        onClick={async () => {
          await saveDraftToHistory("Scanned_Document");
          setActiveTab("history");
        }}
        className="w-full py-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold text-xs text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors flex items-center justify-center space-x-1.5"
      >
        <Save className="w-4 h-4 text-indigo-500" />
        <span>Save Document to History</span>
      </button>
    </div>
  );
};
