import React, { useRef } from "react";
import {
  Camera,
  Image as ImageIcon,
  FileText,
  Clock,
  Sparkles,
  ChevronRight,
  Zap,
  ArrowUpRight,
  Layers,
  Award,
  Cloud,
  CheckCircle2,
  User,
  LogIn,
} from "lucide-react";
import { useDocument } from "../context/DocumentContext";
import { useAdMob } from "../context/AdMobContext";
import { useAuth } from "../context/AuthContext";
import { AdMobBannerAd } from "./AdMobComponents";

export const HomeScreen: React.FC = () => {
  const {
    startNewScan,
    importFromGallery,
    setActiveTab,
    savedDocuments,
    draftPages,
    loadSampleDocument,
    loadSavedDocToDraft,
  } = useDocument();

  const { rewardPoints, showRewarded } = useAdMob();
  const { userProfile, isGuest, setShowAuthModal } = useAuth();
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const totalSavedPages = savedDocuments.reduce((acc, doc) => acc + (doc.pages?.length || 0), 0);

  const handleGalleryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      importFromGallery(e.target.files);
    }
  };

  return (
    <div className="flex flex-col space-y-5 pb-20 select-none">
      {/* Hidden Gallery Input */}
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/jpeg,image/png,image/jpg,image/webp"
        multiple
        onChange={handleGalleryChange}
        className="hidden"
      />

      {/* Firebase Cloud Sync Banner */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl p-3 border border-slate-200 dark:border-slate-700 shadow-xs flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center">
            <Cloud className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                {userProfile ? userProfile.fullName : "Guest Mode"}
              </span>
              <span className="flex items-center space-x-0.5 text-[9px] font-extrabold px-1.5 py-0.2 rounded-md bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                <CheckCircle2 className="w-2.5 h-2.5" />
                <span>Cloud Synced</span>
              </span>
            </div>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">
              {isGuest
                ? "Sign in to backup & sync docs across devices"
                : userProfile?.email || "Firebase Firestore & Storage Active"}
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowAuthModal(true)}
          className="px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 font-extrabold text-xs hover:bg-indigo-100 transition-colors flex items-center space-x-1"
        >
          {userProfile && !isGuest ? <User className="w-3.5 h-3.5" /> : <LogIn className="w-3.5 h-3.5" />}
          <span>{userProfile && !isGuest ? "Account" : "Sign In"}</span>
        </button>
      </div>

      {/* Top Welcome Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-800 text-white p-5 shadow-xl shadow-indigo-600/20">
        <div className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full bg-white/10 blur-xl pointer-events-none" />

        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-[11px] font-bold text-white tracking-wide border border-white/20">
              AI-POWERED
            </span>
            <span className="text-xs text-indigo-200">v2.5 Android M3</span>
          </div>

          <button
            onClick={() => showRewarded()}
            className="flex items-center space-x-1 text-xs bg-amber-400 text-slate-950 font-extrabold px-3 py-1 rounded-full shadow-sm hover:brightness-110 active:scale-95 transition-all"
          >
            <Award className="w-3.5 h-3.5" />
            <span>{rewardPoints} Credits</span>
          </button>
        </div>

        <h2 className="text-xl font-black tracking-tight">Smart Mobile Scanner</h2>
        <p className="text-xs text-indigo-100/90 mt-1 max-w-xs font-medium">
          Auto Edge Crop, Perspective Alignment, AI Shadow Removal & Multilingual OCR.
        </p>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-white/15">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-2.5 text-center">
            <span className="text-lg font-black block leading-none">{savedDocuments.length}</span>
            <span className="text-[10px] text-indigo-200">Scanned Docs</span>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-2.5 text-center">
            <span className="text-lg font-black block leading-none">{totalSavedPages}</span>
            <span className="text-[10px] text-indigo-200">Total Pages</span>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-2.5 text-center">
            <span className="text-lg font-black block leading-none">3</span>
            <span className="text-[10px] text-indigo-200">OCR Languages</span>
          </div>
        </div>
      </div>

      {/* FOUR MAIN BUTTONS GRID */}
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3 px-1">
          Quick Actions
        </h3>

        <div className="grid grid-cols-2 gap-3">
          {/* 1. Scan Document */}
          <button
            onClick={startNewScan}
            className="group relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-500 to-indigo-600 text-white p-4 text-left shadow-lg shadow-indigo-500/20 active:scale-98 transition-all flex flex-col justify-between h-32"
          >
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-white">
              <Camera className="w-5 h-5 group-hover:scale-110 transition-transform" />
            </div>
            <div>
              <span className="font-extrabold text-base block leading-tight">Scan Document</span>
              <span className="text-[11px] text-indigo-100/80 mt-0.5 block">
                Camera with Edge Auto Detect
              </span>
            </div>
          </button>

          {/* 2. Import from Gallery */}
          <button
            onClick={() => galleryInputRef.current?.click()}
            className="group relative overflow-hidden rounded-3xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white p-4 text-left border border-slate-200 dark:border-slate-700 shadow-sm active:scale-98 transition-all flex flex-col justify-between h-32"
          >
            <div className="w-10 h-10 rounded-2xl bg-purple-100 dark:bg-purple-900/40 text-purple-600 dark:text-purple-300 flex items-center justify-center">
              <ImageIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
            </div>
            <div>
              <span className="font-extrabold text-base block leading-tight">Import Gallery</span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 block">
                Supports JPG, PNG & WEBP
              </span>
            </div>
          </button>

          {/* 3. Convert to PDF */}
          <button
            onClick={() => setActiveTab("pdf_creator")}
            className="group relative overflow-hidden rounded-3xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white p-4 text-left border border-slate-200 dark:border-slate-700 shadow-sm active:scale-98 transition-all flex flex-col justify-between h-32"
          >
            <div className="w-10 h-10 rounded-2xl bg-teal-100 dark:bg-teal-900/40 text-teal-600 dark:text-teal-300 flex items-center justify-center">
              <FileText className="w-5 h-5 group-hover:scale-110 transition-transform" />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-base block leading-tight">Convert PDF</span>
                {draftPages.length > 0 && (
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-teal-500 text-slate-950">
                    {draftPages.length} pgs
                  </span>
                )}
              </div>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 block">
                Reorder, Rename & Export
              </span>
            </div>
          </button>

          {/* 4. History */}
          <button
            onClick={() => setActiveTab("history")}
            className="group relative overflow-hidden rounded-3xl bg-white dark:bg-slate-800 text-slate-900 dark:text-white p-4 text-left border border-slate-200 dark:border-slate-700 shadow-sm active:scale-98 transition-all flex flex-col justify-between h-32"
          >
            <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-900/40 text-amber-600 dark:text-amber-300 flex items-center justify-center">
              <Clock className="w-5 h-5 group-hover:scale-110 transition-transform" />
            </div>
            <div>
              <span className="font-extrabold text-base block leading-tight">History</span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 block">
                Saved Scans & OCR Text
              </span>
            </div>
          </button>
        </div>
      </div>

      {/* SAMPLE TEST DOCUMENT LOADERS */}
      <div className="bg-slate-100 dark:bg-slate-800/60 rounded-3xl p-4 border border-slate-200/80 dark:border-slate-700/60">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-1.5">
            <Zap className="w-4 h-4 text-amber-500" />
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
              Instant Sample Documents
            </h4>
          </div>
          <span className="text-[10px] text-slate-500">Try AI Features Now</span>
        </div>
        <p className="text-[11px] text-slate-600 dark:text-slate-400 mb-3">
          Load high-resolution sample scans to test edge crop, AI filter restoration, and OCR without uploading.
        </p>

        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => loadSampleDocument("invoice")}
            className="px-2.5 py-2 rounded-2xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-xs font-bold text-slate-800 dark:text-slate-100 hover:border-indigo-500 transition-colors flex items-center justify-between shadow-xs"
          >
            <span>Invoice</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-indigo-500" />
          </button>

          <button
            onClick={() => loadSampleDocument("urdu_doc")}
            className="px-2.5 py-2 rounded-2xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-xs font-bold text-slate-800 dark:text-slate-100 hover:border-indigo-500 transition-colors flex items-center justify-between shadow-xs"
          >
            <span>Urdu (اردو)</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-indigo-500" />
          </button>

          <button
            onClick={() => loadSampleDocument("arabic_doc")}
            className="px-2.5 py-2 rounded-2xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-xs font-bold text-slate-800 dark:text-slate-100 hover:border-indigo-500 transition-colors flex items-center justify-between shadow-xs"
          >
            <span>Arabic (العربية)</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-indigo-500" />
          </button>
        </div>
      </div>

      {/* ADBANNER AD PLACEHOLDER */}
      <AdMobBannerAd placement="bottom" />

      {/* RECENT SCANS SECTION */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Recent Scans
          </h3>
          {savedDocuments.length > 0 && (
            <button
              onClick={() => setActiveTab("history")}
              className="text-xs font-bold text-indigo-600 dark:text-indigo-400 flex items-center space-x-1"
            >
              <span>View All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {savedDocuments.length === 0 ? (
          <div className="bg-white dark:bg-slate-800/80 rounded-3xl p-6 text-center border border-dashed border-slate-300 dark:border-slate-700">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto mb-2">
              <Layers className="w-6 h-6" />
            </div>
            <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
              No Saved Scans Yet
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
              Tap "Scan Document" or "Import Gallery" above to create your first clean PDF scan!
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {savedDocuments.slice(0, 3).map((doc) => {
              const thumbnail = doc.pages?.[0]?.enhancedImage || doc.pages?.[0]?.croppedImage;
              return (
                <div
                  key={doc.id}
                  onClick={() => loadSavedDocToDraft(doc)}
                  className="bg-white dark:bg-slate-800 rounded-2xl p-3 border border-slate-200 dark:border-slate-700 flex items-center space-x-3 hover:border-indigo-500 dark:hover:border-indigo-400 transition-colors cursor-pointer shadow-xs"
                >
                  <div className="w-12 h-14 rounded-xl bg-slate-100 dark:bg-slate-700 overflow-hidden shrink-0 border border-slate-200 dark:border-slate-600">
                    {thumbnail ? (
                      <img
                        src={thumbnail}
                        alt={doc.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-400">
                        <FileText className="w-5 h-5" />
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {doc.title}
                    </h4>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                      {new Date(doc.createdAt).toLocaleDateString()} &bull; {doc.pages.length} Pages
                    </p>
                    <span className="inline-block mt-1 text-[9px] font-semibold px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300">
                      {doc.category || "Document"}
                    </span>
                  </div>

                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
