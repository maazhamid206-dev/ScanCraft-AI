export type ThemeMode = "light" | "dark" | "system";

export type ActiveTab =
  | "home"
  | "scanner"
  | "crop"
  | "enhancer"
  | "ocr"
  | "pdf_creator"
  | "history"
  | "settings";

export type OCRLanguage = "English" | "Urdu" | "Arabic" | "Auto";

export type DocumentType =
  | "Receipt"
  | "Invoice"
  | "Letter"
  | "Identity Card"
  | "Handwritten Note"
  | "Book Page"
  | "Other";

export interface Point {
  x: number; // percentage 0 - 100
  y: number; // percentage 0 - 100
}

export interface CornerPoints {
  topLeft: Point;
  topRight: Point;
  bottomRight: Point;
  bottomLeft: Point;
}

export interface FilterSettings {
  preset: "original" | "magic_bw" | "color_enhance" | "sharpen" | "shadow_remove" | "grayscale";
  brightness: number; // -100 to 100
  contrast: number; // -100 to 100
  sharpness: number; // 0 to 100
  shadowRemoval: number; // 0 to 100
  noiseReduction: number; // 0 to 100
  bwThreshold: number; // 0 to 255
}

export interface ScanPage {
  id: string;
  originalImage: string; // base64 / data URL
  croppedImage: string; // base64 after crop/perspective
  enhancedImage: string; // base64 after AI/manual filter
  corners: CornerPoints;
  rotation: number; // 0, 90, 180, 270
  filters: FilterSettings;
  ocrResult?: OCRData;
}

export interface OCRData {
  text: string;
  detectedLanguage: OCRLanguage;
  confidenceScore: number;
  documentType: DocumentType;
  wordCount: number;
  keyDetails: string[];
  englishTranslation?: string;
  extractedAt: string;
}

export interface UserProfile {
  uid: string;
  fullName: string;
  email: string;
  profilePhoto?: string;
  isGuest?: boolean;
  createdAt: string;
}

export interface SavedDocument {
  id: string;
  documentId?: string;
  ownerId?: string;
  title: string;
  fileName?: string;
  originalImage?: string;
  enhancedImage?: string;
  pdfFile?: string;
  extractedText?: string;
  language?: string;
  createdAt: string;
  updatedAt: string;
  pages: ScanPage[];
  category: DocumentType;
  tags: string[];
  pdfQuality: "high" | "medium" | "low";
  pdfSizeMb?: number;
}

export interface AppSettings {
  theme: ThemeMode;
  imageQuality: "high" | "medium" | "low"; // 100%, 80%, 60%
  pdfQuality: "high" | "medium" | "low";
  defaultLanguage: OCRLanguage;
  autoCropEnabled: boolean;
  aiEnhanceByDefault: boolean;
  adMobTestMode: boolean;
  soundEffects: boolean;
}

export interface AdMobState {
  bannerEnabled: boolean;
  interstitialLoaded: boolean;
  rewardedLoaded: boolean;
  rewardPoints: number;
}
