import { CornerPoints, FilterSettings } from "../types";

// Default standard quadrilateral corners (5% padding from borders)
export const DEFAULT_CORNERS: CornerPoints = {
  topLeft: { x: 5, y: 5 },
  topRight: { x: 95, y: 5 },
  bottomRight: { x: 95, y: 95 },
  bottomLeft: { x: 5, y: 95 },
};

export const DEFAULT_FILTERS: FilterSettings = {
  preset: "original",
  brightness: 0,
  contrast: 0,
  sharpness: 0,
  shadowRemoval: 0,
  noiseReduction: 0,
  bwThreshold: 128,
};

// Auto detect document edges based on contrast gradient boundaries
export function autoDetectCornersFromImage(
  img: HTMLImageElement | HTMLCanvasElement
): CornerPoints {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  if (!ctx) return DEFAULT_CORNERS;

  canvas.width = 300;
  canvas.height = 400;
  ctx.drawImage(img, 0, 0, 300, 400);

  const imgData = ctx.getImageData(0, 0, 300, 400);
  const data = imgData.data;

  // Simple edge bounding box heuristic
  let minX = 300,
    maxX = 0,
    minY = 400,
    maxY = 0;
  let count = 0;

  for (let y = 10; y < 390; y += 4) {
    for (let x = 10; x < 290; x += 4) {
      const idx = (y * 300 + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const luminance = 0.299 * r + 0.587 * g + 0.114 * b;

      // Identify document body (usually lighter paper than background)
      if (luminance > 70) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
        count++;
      }
    }
  }

  if (count < 100 || maxX - minX < 50 || maxY - minY < 50) {
    return DEFAULT_CORNERS;
  }

  return {
    topLeft: {
      x: Math.max(2, Math.round((minX / 300) * 100)),
      y: Math.max(2, Math.round((minY / 400) * 100)),
    },
    topRight: {
      x: Math.min(98, Math.round((maxX / 300) * 100)),
      y: Math.max(2, Math.round((minY / 400) * 100)),
    },
    bottomRight: {
      x: Math.min(98, Math.round((maxX / 300) * 100)),
      y: Math.min(98, Math.round((maxY / 400) * 100)),
    },
    bottomLeft: {
      x: Math.max(2, Math.round((minX / 300) * 100)),
      y: Math.min(98, Math.round((maxY / 400) * 100)),
    },
  };
}

// Crop & Perspective Correction Warp on Canvas
export function cropAndWarpPerspective(
  imageSrc: string,
  corners: CornerPoints,
  rotationDegrees: number = 0
): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const srcCanvas = document.createElement("canvas");
      const srcCtx = srcCanvas.getContext("2d")!;
      srcCanvas.width = img.width;
      srcCanvas.height = img.height;

      // Handle rotation if needed
      if (rotationDegrees !== 0) {
        if (rotationDegrees === 90 || rotationDegrees === 270) {
          srcCanvas.width = img.height;
          srcCanvas.height = img.width;
        }
        srcCtx.translate(srcCanvas.width / 2, srcCanvas.height / 2);
        srcCtx.rotate((rotationDegrees * Math.PI) / 180);
        srcCtx.drawImage(img, -img.width / 2, -img.height / 2);
      } else {
        srcCtx.drawImage(img, 0, 0);
      }

      const w = srcCanvas.width;
      const h = srcCanvas.height;

      const pxTL = { x: (corners.topLeft.x / 100) * w, y: (corners.topLeft.y / 100) * h };
      const pxTR = { x: (corners.topRight.x / 100) * w, y: (corners.topRight.y / 100) * h };
      const pxBR = { x: (corners.bottomRight.x / 100) * w, y: (corners.bottomRight.y / 100) * h };
      const pxBL = { x: (corners.bottomLeft.x / 100) * w, y: (corners.bottomLeft.y / 100) * h };

      // Calculate dest width and height from corner distances
      const widthTop = Math.hypot(pxTR.x - pxTL.x, pxTR.y - pxTL.y);
      const widthBottom = Math.hypot(pxBR.x - pxBL.x, pxBR.y - pxBL.y);
      const targetWidth = Math.max(widthTop, widthBottom) || w;

      const heightLeft = Math.hypot(pxBL.x - pxTL.x, pxBL.y - pxTL.y);
      const heightRight = Math.hypot(pxBR.x - pxTR.x, pxBR.y - pxTR.y);
      const targetHeight = Math.max(heightLeft, heightRight) || h;

      const outCanvas = document.createElement("canvas");
      outCanvas.width = Math.round(targetWidth);
      outCanvas.height = Math.round(targetHeight);
      const outCtx = outCanvas.getContext("2d")!;

      // Bilinear sampling crop or simple bounding crop warp approximation
      const minX = Math.min(pxTL.x, pxBL.x);
      const minY = Math.min(pxTL.y, pxTR.y);
      const cropW = Math.max(pxTR.x, pxBR.x) - minX;
      const cropH = Math.max(pxBL.y, pxBR.y) - minY;

      outCtx.drawImage(
        srcCanvas,
        Math.max(0, minX),
        Math.max(0, minY),
        Math.min(w - minX, cropW || w),
        Math.min(h - minY, cropH || h),
        0,
        0,
        outCanvas.width,
        outCanvas.height
      );

      resolve(outCanvas.toDataURL("image/jpeg", 0.92));
    };
    img.src = imageSrc;
  });
}

// Apply Filters & AI Enhancements (Magic B&W, Sharpen, Shadow Removal, Contrast, Brightness)
export function processImageFilters(
  imageSrc: string,
  settings: FilterSettings
): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, 0, 0);

      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imgData.data;
      const len = data.length;

      const { preset, brightness, contrast, sharpness, shadowRemoval, bwThreshold } = settings;

      // Brightness and contrast multiplier factors
      const contrastFactor = (259 * (contrast + 255)) / (255 * (259 - contrast));

      for (let i = 0; i < len; i += 4) {
        let r = data[i];
        let g = data[i + 1];
        let b = data[i + 2];

        // 1. Shadow Removal (boosting dark/mid tones)
        if (shadowRemoval > 0 || preset === "shadow_remove") {
          const strength = (shadowRemoval || 50) / 100;
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          if (lum < 160) {
            const boost = (160 - lum) * strength * 0.6;
            r = Math.min(255, r + boost);
            g = Math.min(255, g + boost);
            b = Math.min(255, b + boost);
          }
        }

        // 2. Brightness adjustment
        if (brightness !== 0) {
          r = Math.min(255, Math.max(0, r + brightness));
          g = Math.min(255, Math.max(0, g + brightness));
          b = Math.min(255, Math.max(0, b + brightness));
        }

        // 3. Contrast adjustment
        if (contrast !== 0) {
          r = Math.min(255, Math.max(0, contrastFactor * (r - 128) + 128));
          g = Math.min(255, Math.max(0, contrastFactor * (g - 128) + 128));
          b = Math.min(255, Math.max(0, contrastFactor * (b - 128) + 128));
        }

        // Preset Specific Transformations
        if (preset === "magic_bw" || preset === "grayscale") {
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          if (preset === "magic_bw") {
            // High contrast binary B&W text thresholding
            const val = lum > (bwThreshold || 128) ? 255 : 0;
            data[i] = val;
            data[i + 1] = val;
            data[i + 2] = val;
          } else {
            // Clean Grayscale
            data[i] = lum;
            data[i + 1] = lum;
            data[i + 2] = lum;
          }
        } else if (preset === "color_enhance") {
          // Boost saturation & text clarity
          const avg = (r + g + b) / 3;
          r = Math.min(255, Math.max(0, avg + (r - avg) * 1.35 + 10));
          g = Math.min(255, Math.max(0, avg + (g - avg) * 1.35 + 10));
          b = Math.min(255, Math.max(0, avg + (b - avg) * 1.35 + 10));
          data[i] = r;
          data[i + 1] = g;
          data[i + 2] = b;
        } else {
          data[i] = r;
          data[i + 1] = g;
          data[i + 2] = b;
        }
      }

      ctx.putImageData(imgData, 0, 0);

      // 4. Sharpen Text convolution filter if sharpness > 0
      if (sharpness > 0 || preset === "sharpen") {
        const factor = (sharpness || 40) / 100;
        const tempCanvas = document.createElement("canvas");
        tempCanvas.width = canvas.width;
        tempCanvas.height = canvas.height;
        const tempCtx = tempCanvas.getContext("2d")!;
        tempCtx.putImageData(imgData, 0, 0);

        const srcData = tempCtx.getImageData(0, 0, canvas.width, canvas.height);
        const dstData = ctx.createImageData(canvas.width, canvas.height);
        const w = canvas.width;
        const h = canvas.height;

        const k = factor * 0.8;
        // 3x3 Sharpen Kernel: [0, -k, 0, -k, 1+4k, -k, 0, -k, 0]
        for (let y = 1; y < h - 1; y++) {
          for (let x = 1; x < w - 1; x++) {
            const idx = (y * w + x) * 4;
            for (let c = 0; c < 3; c++) {
              const val =
                (1 + 4 * k) * srcData.data[idx + c] -
                k * srcData.data[((y - 1) * w + x) * 4 + c] -
                k * srcData.data[((y + 1) * w + x) * 4 + c] -
                k * srcData.data[(y * w + (x - 1)) * 4 + c] -
                k * srcData.data[(y * w + (x + 1)) * 4 + c];
              dstData.data[idx + c] = Math.min(255, Math.max(0, val));
            }
            dstData.data[idx + 3] = 255;
          }
        }
        ctx.putImageData(dstData, 0, 0);
      }

      resolve(canvas.toDataURL("image/jpeg", 0.92));
    };
    img.src = imageSrc;
  });
}

// Generates a clean default sample document canvas for initial testing
export function generateSampleDocumentImage(type: "invoice" | "urdu_doc" | "arabic_doc" = "invoice"): string {
  const canvas = document.createElement("canvas");
  canvas.width = 600;
  canvas.height = 800;
  const ctx = canvas.getContext("2d")!;

  // Paper background with slight warm texture
  ctx.fillStyle = "#fdfbf7";
  ctx.fillRect(0, 0, 600, 800);

  // Border & Header
  ctx.strokeStyle = "#1e293b";
  ctx.lineWidth = 4;
  ctx.strokeRect(30, 30, 540, 740);

  // Header Banner
  ctx.fillStyle = "#1e3a8a";
  ctx.fillRect(50, 50, 500, 70);

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 24px sans-serif";
  ctx.fillText("SCANCRAFT AI OFFICIAL DOCUMENT", 70, 92);

  if (type === "urdu_doc") {
    // Urdu document sample
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 22px 'Noto Nastaliq Urdu', Arial, sans-serif";
    ctx.fillText("اسکین کرافٹ اے آئی - دستاویز رپورٹ", 70, 180);

    ctx.font = "18px 'Noto Nastaliq Urdu', Arial, sans-serif";
    ctx.fillText("یہ ایک نمونہ دستاویز ہے جو اسکین کی کوالٹی ٹیسٹ کرنے کے لیے بنائی گئی ہے۔", 70, 230);
    ctx.fillText("نام: محمد علی خان", 70, 280);
    ctx.fillText("تاریخ: ۲ اگست ۲۰۲۶", 70, 320);
    ctx.fillText("حالت: تصدیق شدہ", 70, 360);

    ctx.font = "bold 16px sans-serif";
    ctx.fillText("Document ID: SC-URDU-88492", 70, 420);
    ctx.fillText("Status: AI Verified Clear Text Scan", 70, 450);
  } else if (type === "arabic_doc") {
    // Arabic document sample
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 22px Arial, sans-serif";
    ctx.fillText("تقرير الوثيقة الذكية - سكان كرافت", 70, 180);

    ctx.font = "18px Arial, sans-serif";
    ctx.fillText("هذه وثيقة نموذجية لاختبار جودة المسح الضوئي والتعرف على النصوص.", 70, 230);
    ctx.fillText("الاسم: أحمد بن عبد الله", 70, 280);
    ctx.fillText("التاريخ: ٠٢ أغسطس ٢٠٢٦", 70, 320);
    ctx.fillText("الحالة: موثق ومعتمد", 70, 360);

    ctx.font = "bold 16px sans-serif";
    ctx.fillText("Document ID: SC-ARABIC-99210", 70, 420);
    ctx.fillText("Status: High Resolution OCR Ready", 70, 450);
  } else {
    // English Invoice / Certificate sample
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 20px sans-serif";
    ctx.fillText("INVOICE #SC-2026-9041", 70, 170);

    ctx.font = "14px sans-serif";
    ctx.fillStyle = "#475569";
    ctx.fillText("Date: August 2, 2026", 70, 200);
    ctx.fillText("Billed To: Global Enterprise Tech Ltd.", 70, 220);

    // Table
    ctx.fillStyle = "#e2e8f0";
    ctx.fillRect(70, 260, 460, 35);

    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 14px sans-serif";
    ctx.fillText("ITEM DESCRIPTION", 80, 282);
    ctx.fillText("QTY", 320, 282);
    ctx.fillText("PRICE", 440, 282);

    ctx.font = "14px sans-serif";
    ctx.fillText("AI Document Processing License", 80, 320);
    ctx.fillText("1", 330, 320);
    ctx.fillText("$299.00", 440, 320);

    ctx.fillText("Multilingual OCR Engine (UR/AR/EN)", 80, 350);
    ctx.fillText("1", 330, 350);
    ctx.fillText("$149.00", 440, 350);

    ctx.fillText("Cloud PDF Export & Restoration", 80, 380);
    ctx.fillText("1", 330, 380);
    ctx.fillText("$99.00", 440, 380);

    ctx.strokeStyle = "#cbd5e1";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(70, 410);
    ctx.lineTo(530, 410);
    ctx.stroke();

    ctx.font = "bold 16px sans-serif";
    ctx.fillText("Total Amount Due: $547.00", 300, 450);
  }

  // Stamp Graphic
  ctx.save();
  ctx.translate(420, 600);
  ctx.rotate(-0.2);
  ctx.strokeStyle = "#dc2626";
  ctx.lineWidth = 3;
  ctx.strokeRect(-80, -30, 160, 60);
  ctx.fillStyle = "#dc2626";
  ctx.font = "bold 16px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("APPROVED", 0, 5);
  ctx.font = "10px sans-serif";
  ctx.fillText("ScanCraft AI Certified", 0, 20);
  ctx.restore();

  // Signature line
  ctx.strokeStyle = "#334155";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(70, 680);
  ctx.lineTo(250, 680);
  ctx.stroke();

  ctx.fillStyle = "#64748b";
  ctx.font = "12px sans-serif";
  ctx.fillText("Authorized Signature", 70, 700);

  return canvas.toDataURL("image/jpeg", 0.92);
}
