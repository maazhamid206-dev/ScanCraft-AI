import jsPDF from "jspdf";
import { ScanPage } from "../types";

export interface PDFGenerateOptions {
  title: string;
  quality: "high" | "medium" | "low";
  pageSize: "a4" | "letter" | "fit";
  orientation: "portrait" | "landscape";
  addWatermark: boolean;
  watermarkText?: string;
}

export async function generatePDF(
  pages: ScanPage[],
  options: PDFGenerateOptions
): Promise<{ blob: Blob; dataUrl: string; filename: string }> {
  if (pages.length === 0) {
    throw new Error("No pages provided for PDF generation.");
  }

  const orientation = options.orientation === "landscape" ? "l" : "p";
  const doc = new jsPDF({
    orientation,
    unit: "mm",
    format: options.pageSize === "fit" ? "a4" : options.pageSize,
  });

  const compressionQuality =
    options.quality === "high" ? 0.95 : options.quality === "medium" ? 0.8 : 0.6;

  for (let i = 0; i < pages.length; i++) {
    const page = pages[i];
    const imageSrc = page.enhancedImage || page.croppedImage || page.originalImage;

    if (i > 0) {
      doc.addPage();
    }

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    // Measure image dimensions
    const dimensions = await getImageDimensions(imageSrc);
    const imgRatio = dimensions.width / dimensions.height;
    const pageRatio = pageWidth / pageHeight;

    let renderW = pageWidth;
    let renderH = pageHeight;
    let offsetX = 0;
    let offsetY = 0;

    if (options.pageSize === "fit") {
      if (imgRatio > pageRatio) {
        renderW = pageWidth;
        renderH = pageWidth / imgRatio;
        offsetY = (pageHeight - renderH) / 2;
      } else {
        renderH = pageHeight;
        renderW = pageHeight * imgRatio;
        offsetX = (pageWidth - renderW) / 2;
      }
    }

    doc.addImage(
      imageSrc,
      "JPEG",
      offsetX,
      offsetY,
      renderW,
      renderH,
      `page_${i}`,
      "FAST",
      0
    );

    // Optional Watermark
    if (options.addWatermark) {
      const markText = options.watermarkText || "ScanCraft AI";
      doc.setTextColor(180, 180, 180);
      doc.setFontSize(22);

      // Rotate watermark text on page center
      doc.text(markText, pageWidth / 2, pageHeight / 2, {
        align: "center",
        angle: 45,
      });
    }

    // Page numbers
    doc.setTextColor(100, 100, 100);
    doc.setFontSize(9);
    doc.text(`Page ${i + 1} of ${pages.length}`, pageWidth - 20, pageHeight - 5, {
      align: "right",
    });
  }

  const cleanFilename = (options.title || "ScanCraft_Document")
    .replace(/[^a-z0-9_-]/gi, "_")
    .concat(".pdf");

  const pdfArrayBuffer = doc.output("arraybuffer");
  const blob = new Blob([pdfArrayBuffer], { type: "application/pdf" });
  const dataUrl = doc.output("dataurlstring");

  return { blob, dataUrl, filename: cleanFilename };
}

function getImageDimensions(src: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      resolve({ width: img.width || 600, height: img.height || 800 });
    };
    img.onerror = () => {
      resolve({ width: 600, height: 800 });
    };
    img.src = src;
  });
}
