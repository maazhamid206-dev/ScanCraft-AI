import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

const app = express();
const PORT = Number(process.env.PORT) || 5000;

// Increase payload limits for base64 image scanning
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));

// Initialize Gemini Client safely
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", app: "ScanCraft AI" });
});

// AI OCR Endpoint for Multilingual Document Text Extraction (English, Urdu, Arabic)
app.post("/api/ocr", async (req, res) => {
  try {
    const { imageBase64, mimeType = "image/jpeg", targetLanguage = "Auto" } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: "Missing imageBase64 data." });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(500).json({
        error: "Gemini API Key is missing. Please configure GEMINI_API_KEY in Secrets.",
      });
    }

    // Strip data URL prefix if present
    const cleanBase64 = imageBase64.replace(/^data:image\/[a-z]+;base64,/, "");

    const langInstruction =
      targetLanguage === "Urdu"
        ? "Extract text specifically recognizing Urdu script (Nastaliq/Naskh) along with any numbers or English text present."
        : targetLanguage === "Arabic"
        ? "Extract text specifically recognizing Arabic script with accurate diacritics and formatting."
        : targetLanguage === "English"
        ? "Extract text specifically targeting English language document text."
        : "Automatically detect and extract text in English, Urdu, or Arabic, preserving exact language formatting and line breaks.";

    const prompt = `${langInstruction}
Analyze the provided document image and extract all visible text with high accuracy.
Return a JSON object matching this schema strictly:
{
  "text": "Full extracted document text preserving line breaks and original script formatting",
  "detectedLanguage": "English" | "Urdu" | "Arabic" | "Multilingual",
  "confidenceScore": 98,
  "documentType": "Receipt" | "Invoice" | "Letter" | "Identity Card" | "Handwritten Note" | "Book Page" | "Other",
  "wordCount": 120,
  "keyDetails": ["Key point or summary bullet 1", "Key point 2"],
  "englishTranslation": "Optional translation to English if original text was Urdu or Arabic"
}
Ensure response contains valid JSON only with no additional prose markdown.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: [
        {
          parts: [
            {
              inlineData: {
                mimeType,
                data: cleanBase64,
              },
            },
            {
              text: prompt,
            },
          ],
        },
      ],
      config: {
        responseMimeType: "application/json",
      },
    });

    const rawText = response.text || "{}";
    let parsedResult;
    try {
      parsedResult = JSON.parse(rawText);
    } catch {
      parsedResult = {
        text: rawText,
        detectedLanguage: targetLanguage,
        confidenceScore: 90,
        documentType: "Document",
        wordCount: rawText.split(/\s+/).length,
        keyDetails: [],
      };
    }

    return res.json({ success: true, result: parsedResult });
  } catch (error: any) {
    console.error("OCR API error:", error);
    return res.status(500).json({
      error: error.message || "Failed to perform AI OCR text extraction.",
    });
  }
});

// AI Document Quality & Filter Advisor Endpoint
app.post("/api/enhance-ai", async (req, res) => {
  try {
    const { imageBase64, mimeType = "image/jpeg" } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: "Missing imageBase64 data." });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(500).json({
        error: "Gemini API Key is missing. Please configure GEMINI_API_KEY in Secrets.",
      });
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/[a-z]+;base64,/, "");

    const prompt = `Analyze this document scan for optical quality and suggest optimal restoration parameters.
Return a JSON object strictly following this structure:
{
  "qualityScore": 85,
  "blurDetected": false,
  "shadowDetected": true,
  "recommendedPreset": "Magic B&W" | "Color Enhance" | "Sharpen Text" | "Shadow Removal",
  "brightnessAdjustment": 15,
  "contrastAdjustment": 25,
  "sharpnessAmount": 40,
  "shadowRemovalStrength": 60,
  "noiseReductionLevel": 30,
  "suggestedCropMargins": "Clean document borders detected",
  "documentSummary": "Clear scan of a printed document with minor shadows near top edge."
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: [
        {
          parts: [
            {
              inlineData: {
                mimeType,
                data: cleanBase64,
              },
            },
            {
              text: prompt,
            },
          ],
        },
      ],
      config: {
        responseMimeType: "application/json",
      },
    });

    const rawText = response.text || "{}";
    const result = JSON.parse(rawText);
    return res.json({ success: true, result });
  } catch (error: any) {
    console.error("AI Enhance API error:", error);
    return res.status(500).json({
      error: error.message || "Failed to analyze document quality.",
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ScanCraft AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
