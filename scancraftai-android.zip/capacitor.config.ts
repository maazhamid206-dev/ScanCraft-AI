import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.scancraftai.app',
  appName: 'ScanCraft AI',
  webDir: 'dist',
  android: {
    buildOptions: {
      releaseType: 'APK',
    },
  },
  plugins: {
    AdMob: {
      // AppId is set in AndroidManifest.xml (com.google.android.gms.ads.APPLICATION_ID).
      // These are runtime options passed to AdMob.initialize() on first launch.
      initializeForTesting: false,
      testingDevices: [],
    },
  },
};

export default config;
